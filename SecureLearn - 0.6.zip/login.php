<?php
session_start();
require_once "assets/config.php";

$max_attempts = 5;
$lockout_time = 300; // 5 minutes

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = trim($_POST['role'] ?? '');
    $email = trim($_POST['Email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($role) || empty($email) || empty($password)) {
        header("Location: index.php?login_error=" . urlencode("Email, Password and Role are required.") . "&role=$role");
        exit;
    }

    if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = [];
    $attempt_key = $role . ':' . $email;
    $attempt_data = $_SESSION['login_attempts'][$attempt_key] ?? ['count'=>0,'locked_until'=>0];
    $now = time();

    if ($attempt_data['locked_until'] > $now) {
        $remaining = $attempt_data['locked_until'] - $now;
        header("Location: index.php?login_error=" . urlencode("Too many failed attempts. Try again in $remaining s") . "&role=$role&locked_until=" . $attempt_data['locked_until']);
        exit;
    }

    // Fetch user
    $stmt = mysqli_prepare($conn, "SELECT id, password_hash, role FROM users WHERE email=?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $uid, $password_hash, $db_role);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if ($uid && password_verify($password, $password_hash)) {
        if ($role !== $db_role) {
            $attempt_data['count']++;
            $errMsg = "Incorrect role for this account.";
        } else {
            $_SESSION['uid'] = $uid;
            unset($_SESSION['login_attempts'][$attempt_key]);
            if ($role === 'student') header("Location: student_panel/index.php");
            elseif ($role === 'teacher') header("Location: teacher_panel/dashboard.php");
            elseif ($role === 'admin') header("Location: admin_panel/dashboard.php");
            exit;
        }
    } else {
        $attempt_data['count']++;
        $errMsg = "Incorrect Email/Password or Role.";
    }

    if ($attempt_data['count'] >= $max_attempts) {
        $attempt_data['locked_until'] = $now + $lockout_time;
        $attempt_data['count'] = 0;
    }

    $_SESSION['login_attempts'][$attempt_key] = $attempt_data;

    header("Location: index.php?login_error=" . urlencode($errMsg) . "&role=$role&attempts=" . $attempt_data['count'] . "&locked_until=" . ($attempt_data['locked_until'] ?? 0));
    exit;
}
?>
