<?php
session_start();
require_once "assets/config.php"; // database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = trim($_POST['role'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if (!$role || !$email) {
        echo json_encode(['status'=>'error','msg'=>'Role and email required.']);
        exit;
    }

    // Fetch user
    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email=? AND role=?");
    mysqli_stmt_bind_param($stmt, "ss", $email, $role);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $uid);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if (!$uid) {
        // Security: Don't tell whether email exists
        echo json_encode(['status'=>'ok']);
        exit;
    }

    // Generate secure token
    $token = bin2hex(random_bytes(32));
    $expires = date("Y-m-d H:i:s", time() + 900); // 15 minutes

    // Store in database
    $stmt = mysqli_prepare($conn, "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "iss", $uid, $token, $expires);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Send email (replace with your SMTP / mail config)
    $resetLink = "https://yourdomain.com/resetPassword.php?token=$token";
    $subject = "Password Reset Request";
    $message = "Click the link to reset your password (expires in 15 min): $resetLink";
    $headers = "From: no-reply@yourdomain.com\r\n";

    mail($email, $subject, $message, $headers);

    echo json_encode(['status'=>'ok']);
    exit;
}
?>
