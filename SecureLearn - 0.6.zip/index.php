
<?php
// index.php
// Your header include
include('shared/_header.php');
?>
<main>
  <div class="big-wrapper light">
    <img src="./images/shape.png" alt="" class="shape" />

    <?php include('shared/_navbar.php'); ?>

    <!-- Hero Section -->
    <div class="container my-5">
      <div class="row g-4 align-items-center">
        <!-- Text Block -->
        <div class="col-12 col-md-6 d-flex justify-content-center">
          <div class="text-center text-md-start">
            <div class="big-title mb-3">
              <h1 class="fw-bold display-5">Future is here,</h1>
              <h1 class="fw-bold display-5">Start Exploring now.</h1>
            </div>
            <p class="text-muted lead mb-4">
              Learn how to do ethical hacking and how to prevent them,
              and enhance Cybersecurity awareness effectively!
            </p>
            <div class="cta">
              <!-- Trigger Role Selection Modal -->
              <button class="btn btn-primary btn-lg px-4" data-bs-toggle="modal" data-bs-target="#loginRoleModal">
                Get started
              </button>
            </div>
          </div>
        </div>

        <!-- Image Block -->
        <div class="col-12 col-md-6">
          <img src="./images/children.jpg" alt="Person Image" class="img-fluid rounded shadow-sm" />
        </div>
      </div>
    </div>

    <!-- Feature Cards -->
    <?php include('shared/feature-cards.php'); ?>

    <!-- Divider -->
    <div class="container my-4">
      <hr>
    </div>

    <!-- Carousel -->
    <div class="container my-4 carousel-box">
      <div id="carouselExample" class="carousel slide">
        <div class="carousel-inner rounded shadow-sm">
          <div class="carousel-item active">
            <img src="images/learning.png" class="d-block w-100" alt="Slide 1">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
</main>


<div class="modal fade modal-theme" id="loginRoleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg rounded-4">
            <div class="modal-header border-0">
                <h5 class="modal-title fw-bold">Are you a.....?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 text-center">
                    <div class="col-4">
                        <div class="role-card role-student d-flex flex-column justify-content-center align-items-center" data-role="student">
                            <img src="images/student.png" alt="Student" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                            <h6 class="fw-bold">Student</h6>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="role-card role-teacher d-flex flex-column justify-content-center align-items-center" data-role="teacher">
                            <img src="images/teacher.png" alt="Teacher" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                            <h6 class="fw-bold">Teacher</h6>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="role-card role-admin d-flex flex-column justify-content-center align-items-center" data-role="admin">
                            <img src="images/admin.png" alt="Admin" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                            <h6 class="fw-bold">Staff / Admin</h6>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-3">
                   <a href="#" class="text-decoration-underline text-muted small" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
    Lost / Forgot password?
</a>
                </div>
            </div>
        </div>
    </div>
</div>

<hr>

<div class="modal fade modal-theme" id="loginModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg rounded-4 p-4">
            <div class="modal-header border-0">
                <h5 class="modal-title fw-bold">Login as <span id="selectedRoleLabel">User</span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="roleLoginForm" method="POST" action="login.php" novalidate>
                    <input type="hidden" name="role" id="roleField" value="">
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="Email" name="Email" id="loginUsername" class="form-control shadow-sm" placeholder="Enter your email" required>
                    </div>
                    <div class="mb-3 position-relative">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" id="loginPassword" class="form-control shadow-sm" placeholder="Enter your password" required>
                    </div>

                    <div id="serverStatus" class="mb-3" style="display:none;"></div>

                    <button id="loginSubmitBtn" type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Forgot Password Modal -->
<div class="modal fade modal-theme" id="forgotPasswordModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow-lg rounded-4 p-4">
      <div class="modal-header border-0">
        <h5 class="modal-title fw-bold">Forgot Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-3">Enter your email and role to receive a password reset link:</p>
        <form id="forgotPasswordForm" method="POST" action="ForgotPassword_BE.php">
          <div class="mb-3">
            <label class="form-label">Role</label>
<div class="row g-3 text-center mb-3">
  <div class="col-4">
    <div class="role-card role-student d-flex flex-column justify-content-center align-items-center" data-role="student">
      <img src="images/student.png" alt="Student" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
      <h6 class="fw-bold">Student</h6>
    </div>
  </div>
  <div class="col-4">
    <div class="role-card role-teacher d-flex flex-column justify-content-center align-items-center" data-role="teacher">
      <img src="images/teacher.png" alt="Teacher" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
      <h6 class="fw-bold">Teacher</h6>
    </div>
  </div>
  <div class="col-4">
    <div class="role-card role-admin d-flex flex-column justify-content-center align-items-center" data-role="admin">
      <img src="images/admin.png" alt="Admin" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
      <h6 class="fw-bold">Staff / Admin</h6>
    </div>
  </div>
</div>

<!-- Hidden input to store selected role -->
<input type="hidden" name="role" id="forgotRoleField" value="">
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control shadow-sm" placeholder="Enter your email" required>
          </div>
          <div id="forgotStatus" class="mb-3" style="display:none;"></div>
          <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
const forgotModal = document.getElementById('forgotPasswordModal');
if (forgotModal) {
  const roleCards = forgotModal.querySelectorAll('.role-card');
  const roleField = document.getElementById('forgotRoleField');

  roleCards.forEach(card => {
    card.addEventListener('click', function() {
      // Remove highlight from all cards
      roleCards.forEach(c => c.classList.remove('selected-role'));
      // Add highlight to clicked card
      card.classList.add('selected-role');

      // Set hidden input
      if (roleField) roleField.value = card.getAttribute('data-role');
      
      // Get the Bootstrap modal instance
      const myModal = bootstrap.Modal.getInstance(forgotModal);
      if (myModal) {
        // Manually hide the modal, which removes the backdrop
        myModal.hide();
        
        // Use a short delay to allow the modal to fully hide
        setTimeout(() => {
          // Re-show the modal, which will create a fresh, non-dimmed backdrop
          myModal.show();
        }, 300); // 300ms is a safe delay to let the animation finish
      }
    });
  });
}
</script>


<style>
#forgotPasswordModal .role-card.selected-role {
  border-color: #0d6efd !important; /* highlight border */
  box-shadow: 0 4px 12px rgba(13,110,253,0.5) !important; /* stronger shadow */
}
  .role-card {
    height: 120px;
    border-radius: 12px;
    cursor: pointer;
    border: 2px solid transparent;
    transition: all 0.3s ease;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  }
  .role-card:hover {
    transform: scale(1.05);
    border-color: #333;
  }
  .role-student {
    background-color: rgba(0, 128, 0, 0.15);
    border: 2px solid rgba(0, 128, 0, 0.4);
  }
  .role-teacher {
    background-color: rgba(255, 193, 7, 0.15);
    border: 2px solid rgba(255, 193, 7, 0.5);
  }
  .role-admin {
    background-color: rgba(220, 53, 69, 0.15);
    border: 2px solid rgba(220, 53, 69, 0.5);
  }

  /* disabled look */
  .locked {
    opacity: 0.6;
    pointer-events: none;
  }
  
  /* Default light theme */
.modal-theme .modal-content {
  background-color: #fff;
  color: #212529;
  border: 1px solid #ddd;
}

/* Dark theme when .dark is present on modal */
.modal-theme.dark .modal-content {
  background-color: #192e3a;
  color: #f5f5f5;
  border: 1px solid #5bacdf;
}

/* Buttons */
.modal-theme .btn-primary {
  background-color: #0d6efd;
  border-color: #0d6efd;
}
.modal-theme.dark .btn-primary {
  background-color: #375a7f;
  border-color: #375a7f;
}

/* Inputs */
.modal-theme .form-control {
  background-color: #fff;
  color: #212529;
  border: 1px solid #ced4da;
}
.modal-theme.dark .form-control {
  background-color: #2c2c2c;
  color: #f5f5f5;
  border: 1px solid #555;
}

/* Role cards */
.modal-theme .role-card { transition: all 0.3s ease; }
.modal-theme.dark .role-card.role-student {
  background-color: rgba(0, 128, 0, 0.25);
  border-color: rgba(0, 128, 0, 0.5);
}
.modal-theme.dark .role-card.role-teacher {
  background-color: rgba(255, 193, 7, 0.25);
  border-color: rgba(255, 193, 7, 0.6);
}
.modal-theme.dark .role-card.role-admin {
  background-color: rgba(220, 53, 69, 0.25);
  border-color: rgba(220, 53, 69, 0.6);
}
</style>

<script>
  const toggleBtn = document.querySelector('.toggle-btn');
  const modals = document.querySelectorAll('.modal-theme');

  toggleBtn.addEventListener('click', () => {
    modals.forEach(modal => {
      modal.classList.toggle('dark'); // add or remove dark class
    });
  });
</script>

<script>
  // open loginModal after role click, set hidden field
  document.querySelectorAll('.role-card').forEach(card => {
    card.addEventListener('click', function() {
      const role = card.getAttribute('data-role');
      document.getElementById('selectedRoleLabel').textContent = role.charAt(0).toUpperCase() + role.slice(1);
      document.getElementById('roleField').value = role;
      // close role modal then open login modal
      const roleModalEl = document.getElementById('loginRoleModal');
      const roleModal = bootstrap.Modal.getInstance(roleModalEl) || new bootstrap.Modal(roleModalEl);
      roleModal.hide();
      const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
      loginModal.show();
    });
  });

  // If server redirected back with query params, parse them and set up UI
  (function() {
    const url = new URL(window.location.href);
    const loginError = url.searchParams.get('login_error'); // message
    const role = url.searchParams.get('role'); // role that was being used
    const attempts = url.searchParams.get('attempts'); // numeric
    const locked_until = url.searchParams.get('locked_until'); // epoch seconds if exists

    if (role) {
      // open login modal and set role
      const roleModalEl = document.getElementById('loginRoleModal');
      const roleModal = bootstrap.Modal.getInstance(roleModalEl);
      if (roleModal) roleModal.hide();
      document.getElementById('selectedRoleLabel').textContent = role.charAt(0).toUpperCase() + role.slice(1);
      document.getElementById('roleField').value = role;
      const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
      loginModal.show();
    }

    if (loginError) {
      const status = document.getElementById('serverStatus');
      status.style.display = 'block';
      status.innerHTML = '<div class="alert alert-danger mb-0">' + decodeURIComponent(loginError) + '</div>';
    }

    if (locked_until) {
      const lockedUntil = parseInt(locked_until, 10);
      const now = Math.floor(Date.now() / 1000);
      const remaining = lockedUntil - now;
      if (remaining > 0) {
        // disable inputs & show countdown
        const username = document.getElementById('loginUsername');
        const password = document.getElementById('loginPassword');
        const btn = document.getElementById('loginSubmitBtn');
        username.disabled = true;
        password.disabled = true;
        btn.disabled = true;
        btn.classList.add('disabled');

        const status = document.getElementById('serverStatus');
        status.style.display = 'block';
        status.innerHTML = '<div class="alert alert-warning mb-0">Too many failed attempts. Try again in <span id="countdown">' + remaining + '</span> s</div>';

        // countdown tick
        let rem = remaining;
        const interval = setInterval(() => {
          rem--;
          const cd = document.getElementById('countdown');
          if (cd) cd.textContent = rem;
          if (rem <= 0) {
            clearInterval(interval);
            // reload page without the lock params so form re-enables
            url.searchParams.delete('locked_until');
            url.searchParams.delete('attempts');
            url.searchParams.delete('login_error');
            url.searchParams.delete('role');
            window.location.href = url.toString();
          }
        }, 1000);
      }
    }
  })();
</script>

<?php include('shared/_footer.php'); ?>
