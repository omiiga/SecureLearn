<html>
<body>
	<p>
	<div align="center"><b><h1> Did you notice anything changed? Browse the site.</h1></b></div> 
	<!-- "There are 2 hints under the File Inclusion folder. They should be there ->  " <!-->
	<!-- "Hint1 : FileInclusion\pages\dontOpen\hint1.php <!-->
	<!-- "Hint2 : FileInclusion\hint2\hint2.php" <!-->
	<!-- "Paste the paths to the URL is not a solution!!" <!-->
</body>
</html>
