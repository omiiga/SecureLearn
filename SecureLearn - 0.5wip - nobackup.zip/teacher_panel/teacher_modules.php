<?php 
// Session and role verification from your second file
include("../assets/noSessionRedirect.php"); 
include("./verifyRoleRedirect.php"); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Modules</title>
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="shortcut icon" href="../Resources/hmbct.png" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/oranbyte-google-translator.css">
    <script src="../js/oranbyte-google-translator.js" defer></script>

    <style>
        body {
            background-color: #f6f6f9;
            color: #363949;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-family: 'Inter', sans-serif;
            margin: 0; padding: 0;
        }
        body.dark-mode {
            background-color: #181a1e;
            color: #edeffd;
        }
        .navbar a { color: #363949; transition: color 0.3s ease; }
        body.dark-mode .navbar a { color: #edeffd; }

        .module-wrapper {
            margin: auto; max-width: 800px; padding: 20px;
            background-color: #fff; /* Changed from e0e0e0 for better contrast */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease, color 0.3s ease;
            margin-top: 2rem;
        }
        body.dark-mode .module-wrapper { background-color: #2f3d4a; }

        .module-wrapper h2 {
            color: #333; transition: color 0.3s ease;
        }
        body.dark-mode .module-wrapper h2 { color: #f0f0f0; }

        /* Folder & File Listing */
        .folder { margin-bottom: 10px; }
        .folder-name {
            font-weight: bold; cursor: pointer; padding: 10px;
            background: #f0f0f0; border-radius: 5px; color: #333;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        body.dark-mode .folder-name { background: #25303a; color: #d4d4d4; }

        .file-list {
            display: none; margin-left: 20px; margin-top: 5px;
            padding-left: 10px; border-left: 1px solid #ddd;
        }
        .file-list li {
            margin: 12px 0; list-style: none; display: flex;
            flex-wrap: wrap; align-items: center; gap: 10px;
        }
        .file-list li span { flex-grow: 1; }
        body.dark-mode .file-list { color: #cccccc; border-left-color: #444; }
        body.dark-mode .file-list li span { color: #cccccc; }
        
        .rename-field {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .launch-btn {
            background-color: #8f99ed; color: black; border: none;
            padding: 6px 12px; border-radius: 4px; cursor: pointer;
            font-size: 0.9rem;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }
        .launch-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(54,57,73,0.2);
        }
        body.dark-mode .launch-btn { background-color: #5a7d9a; color: #f0f0f0; }

        /* Submission Table */
        .submissions { margin-top: 30px; }
        .submissions table { width: 100%; border-collapse: collapse; }
        .submissions th, .submissions td {
            padding: 8px; border: 1px solid #bbb;
            text-align: left;
        }
        body.dark-mode .submissions th,
        body.dark-mode .submissions td { border-color: #444; }

        /* Windows-like UI and Message Box styles */
        .module-window-container { display: none; flex-direction: column; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 90vw; height: 90vh; max-width: 1200px; background-color: white; box-shadow: 0 10px 30px rgba(0,0,0,0.2); z-index: 1001; border-radius: 8px; overflow: hidden; }
        .title-bar { display: flex; justify-content: space-between; align-items: center; background-color: #eee; padding: 5px 10px; cursor: grab; }
        body.dark-mode .module-window-container { background-color: #1e2a36; }
        body.dark-mode .title-bar { background-color: #2f3d4a; }
        .module-title { font-weight: bold; }
        .window-controls button { background: none; border: none; cursor: pointer; font-size: 1.2rem;}
        .module-iframe { flex-grow: 1; border: none; }
        .popup-bg { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); z-index: 1000; }
        .minimized-modules-container { position: fixed; bottom: 10px; left: 10px; z-index: 1002; display: flex; gap: 10px; }
        .minimized-bubble { background: #fff; padding: 10px 15px; border-radius: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); cursor: pointer; display: flex; align-items: center; gap: 8px; }
        body.dark-mode .minimized-bubble { background: #2f3d4a; }
        .message-box-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); z-index: 2000; justify-content: center; align-items: center; }
        .message-box { background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        body.dark-mode .message-box { background: #2f3d4a; }
        .message-box button { margin-top: 15px; padding: 8px 20px; cursor: pointer; }
    </style>
</head>
<body>

<header>
   <?php include('partials/_header.php') ?>

</header>
<?php include('partials/_sidebar.php') ?>
<input type="hidden" value="1" id="checkFileName">
<div class="content">

    <main class="module-wrapper">
        <h2 style="text-align:center;">Manage Modules</h2>

        <?php
        // Path to your modules directory
        $modulesPath = realpath(__DIR__ . '/../modules');
        if ($modulesPath && is_dir($modulesPath)) {
            $folders = scandir($modulesPath);
            foreach ($folders as $folder) {
                if ($folder === '.' || $folder === '..' || $folder === 'Resources') continue;
                $folderPath = $modulesPath . DIRECTORY_SEPARATOR . $folder;
                if (is_dir($folderPath)) {
                    echo "<div class='folder'>";
                    echo "<div class='folder-name' onclick=\"toggleList('".htmlspecialchars($folder,ENT_QUOTES)."')\">"
                        . htmlspecialchars($folder)
                        . "</div>";
                    echo "<ul class='file-list' id='list-".htmlspecialchars($folder,ENT_QUOTES)."'>";
                    $files = scandir($folderPath);
                    foreach ($files as $file) {
                        if (pathinfo($file, PATHINFO_EXTENSION)==='php') {
                            $relPath = "../modules/".urlencode($folder)."/".urlencode($file);
                            $moduleTitle = htmlspecialchars(pathinfo($file, PATHINFO_FILENAME));
                            echo "<li>"
                                . "<input type='checkbox' class='toggle-vis' data-path='{$relPath}'>"
                                . "<span>{$moduleTitle}</span>"
                                . "<input type='text' class='rename-field' value='{$moduleTitle}'>"
                                . "<button class='launch-btn save-rename' data-path='{$relPath}'>Rename</button>"
                                . "<button class='launch-btn view-stats' data-path='{$relPath}'>View Submissions</button>"
                                . "</li>";
                        }
                    }
                    echo "</ul></div>";
                }
            }
        } else {
            echo '<p>Modules directory not found.</p>';
        }
        ?>

        <div class="submissions" id="submissions-panel" style="display:none;">
            <h2>Student Submissions</h2>
            <label>Section:
                <select id="section-filter">
                    <option value="">All</option>
                    <?php
                    // Example: hardcode or fetch real sections
                    foreach (['A','B','C'] as $sec) {
                        echo "<option value='{$sec}'>{$sec}</option>";
                    }
                    ?>
                </select>
            </label>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Tries</th>
                        <th>Status</th>
                        <th>Score</th>
                    </tr>
                </thead>
                <tbody id="subs-body">
                    </tbody>
            </table>
        </div>
    </main>
</div>

<div id="module-window-container" class="module-window-container">
    <div class="title-bar">
        <span id="module-title" class="module-title">Module Title</span>
        <div class="window-controls">
            <button class="control-btn minimize-btn" title="Minimize" onclick="minimizeModule()"><span class="material-icons-sharp">remove</span></button>
            <button class="control-btn close-btn" title="Close" onclick="closeModule()"><span class="material-icons-sharp">close</span></button>
        </div>
    </div>
    <iframe id="module-iframe" class="module-iframe"></iframe>
</div>

<div id="minimized-modules-container" class="minimized-modules-container"></div>
<div id="popup-bg" class="popup-bg" onclick="closeModule()"></div>

<div id="message-box-overlay" class="message-box-overlay">
    <div class="message-box">
        <h3 id="message-box-title"></h3>
        <p id="message-box-text"></p>
        <button onclick="hideMessageBox()">OK</button>
    </div>
</div>

<script>
    let currentModule = { url: '', title: '', isMinimized: false, isOpen: false };

    function showMessageBox(title, message) {
        document.getElementById('message-box-title').textContent = title;
        document.getElementById('message-box-text').textContent = message;
        document.getElementById('message-box-overlay').style.display = 'flex';
    }

    function hideMessageBox() {
        document.getElementById('message-box-overlay').style.display = 'none';
    }

    function toggleList(id) {
        const list = document.getElementById('list-' + id);
        list.style.display = (list.style.display === 'block') ? 'none' : 'block';
    }

    function openModuleFullscreen(url, title) {
        const container = document.getElementById('module-window-container');
        const iframe = document.getElementById('module-iframe');
        const moduleTitleSpan = document.getElementById('module-title');
        const bg = document.getElementById('popup-bg');
        
        closeModule(); // Close any existing module first

        currentModule = { url, title, isOpen: true, isMinimized: false };

        moduleTitleSpan.textContent = title;
        iframe.src = url;
        container.style.display = 'flex';
        bg.style.display = 'block';
        document.getElementById('minimized-modules-container').innerHTML = '';
    }

    function minimizeModule() {
        if (!currentModule.isOpen || currentModule.isMinimized) return;
        
        document.getElementById('module-window-container').style.display = 'none';
        document.getElementById('popup-bg').style.display = 'none';
        currentModule.isMinimized = true;

        const minimizedContainer = document.getElementById('minimized-modules-container');
        const bubble = document.createElement('div');
        bubble.className = 'minimized-bubble';
        bubble.innerHTML = `<span class="material-icons-sharp">folder</span><span>${currentModule.title}</span>`;
        bubble.onclick = restoreModule;
        minimizedContainer.appendChild(bubble);
    }

    function restoreModule() {
        if (!currentModule.isOpen || !currentModule.isMinimized) return;

        document.getElementById('module-window-container').style.display = 'flex';
        document.getElementById('popup-bg').style.display = 'block';
        document.getElementById('minimized-modules-container').innerHTML = '';
        currentModule.isMinimized = false;
    }

    function closeModule() {
        document.getElementById('module-iframe').src = 'about:blank';
        document.getElementById('module-window-container').style.display = 'none';
        document.getElementById('popup-bg').style.display = 'none';
        document.getElementById('minimized-modules-container').innerHTML = '';
        currentModule = { url: '', title: '', isMinimized: false, isOpen: false };
    }

    // Placeholder functions for teacher actions
    function setupTeacherEventListeners() {
        document.querySelectorAll('.save-rename').forEach(button => {
            button.addEventListener('click', (e) => {
                const path = e.target.dataset.path;
                const newName = e.target.previousElementSibling.value;
                console.log(`AJAX call to rename: ${path} to ${newName}`);
                showMessageBox('Rename Action', `Would attempt to rename module to "${newName}".`);
                // Add actual fetch/AJAX call to api/renameModule.php here
            });
        });

        document.querySelectorAll('.view-stats').forEach(button => {
            button.addEventListener('click', (e) => {
                const path = e.target.dataset.path;
                document.getElementById('submissions-panel').style.display = 'block';
                 console.log(`AJAX call to get stats for: ${path}`);
                 showMessageBox('View Submissions', `Would fetch submissions for this module.`);
                // Add actual fetch/AJAX call to api/getSubmissions.php here
            });
        });
        
        document.querySelectorAll('.toggle-vis').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                const path = e.target.dataset.path;
                const isVisible = e.target.checked;
                console.log(`AJAX call to set visibility for ${path} to ${isVisible}`);
                showMessageBox('Visibility Changed', `Module visibility would be updated.`);
                 // Add actual fetch/AJAX call to api/toggleVisibility.php here
            });
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        const themeToggler = document.querySelector('.theme-toggler');
        const body = document.body;
        

        // Setup listeners for teacher-specific buttons
        setupTeacherEventListeners();
    });
</script>

<script src="app.js" defer></script>

</body>
</html>