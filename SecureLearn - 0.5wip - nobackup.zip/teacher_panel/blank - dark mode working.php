<?php include('partials/_header.php') ?>
<!-- Sidebar -->
<?php include('partials/_sidebar.php') ?>
<input type="hidden" value="2" id="checkFileName">
<!-- End of Sidebar -->

<!-- Main Content -->
<div class="content">
    <!-- Navbar -->
    <?php include("partials/_navbar.php"); ?>
    <!-- End of Navbar -->
</div>


<script src="../assets/js/student.js"></script>
<?php include('partials/_footer.php'); ?>