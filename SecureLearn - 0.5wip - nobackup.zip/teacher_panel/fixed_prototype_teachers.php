<?php include('partials/_header.php') ?>

<!-- Sidebar -->
<?php include('partials/_sidebar.php') ?>
<input type="hidden" value="11" id="checkFileName">
<!-- End of Sidebar -->

<!-- Main Content -->
<div class="content">
  <!-- Navbar -->
  <?php include("partials/_navbar.php"); ?>
  <!-- End of Navbar -->

  <!-- Module Management -->
  <main class="module-wrapper container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <center><h1 class="h3 mb-0">Manage Modules</h1></center>
      <button type="button" class="btn btn-sm btn-outline-secondary" onclick="refreshModules()">
        <i class="bi bi-arrow-clockwise"></i> Refresh
      </button>
    </div>

    <?php
	
    $modulesPath = realpath(__DIR__ . '/../modules');
    if ($modulesPath && is_dir($modulesPath)) {
        foreach (scandir($modulesPath) as $folder) {
            if (in_array($folder, ['.', '..', 'Resources'], true)) continue;
            $folderPath = $modulesPath . DIRECTORY_SEPARATOR . $folder;
            if (!is_dir($folderPath)) continue;

            // safe ID
            $idKey = preg_replace('/[^A-Za-z0-9_]/', '_', $folder);
            $safeFolder = htmlspecialchars($folder, ENT_QUOTES);

            echo "<div class=\"card mb-3 bg-body text-body\">";
            echo "  <div class=\"card-header d-flex justify-content-between align-items-center\"";
            echo "       role=\"button\" onclick=\"toggleList('$idKey')\">";
            echo "    <span>$safeFolder</span>";
            echo "    <i id=\"icon-$idKey\" class=\"bi bi-chevron-down\"></i>";
            echo "  </div>";
            echo "  <ul class=\"list-group list-group-flush file-list\" id=\"list-$idKey\" style=\"display: none;\">";

            foreach (scandir($folderPath) as $file) {
                if (in_array($file, ['.', '..'], true)) continue;
                if (pathinfo($file, PATHINFO_EXTENSION) !== 'php') continue;

                $title      = pathinfo($file, PATHINFO_FILENAME);
                $safeTitle  = htmlspecialchars($title, ENT_QUOTES);
                $relPath    = "../modules/$folder/$file";
                $relEscaped = htmlspecialchars($relPath, ENT_QUOTES);
                $chkId      = "chk-{$idKey}-{$safeTitle}";

                echo "    <li class=\"list-group-item d-flex align-items-center flex-wrap\">";
                echo "      <div class=\"form-check me-3\">";
                echo "        <input class=\"form-check-input toggle-vis\" type=\"checkbox\"";
                echo "               data-path=\"$relEscaped\" id=\"$chkId\">";
                echo "        <label class=\"form-check-label\" for=\"$chkId\">$safeTitle</label>";
                echo "      </div>";
                echo "      <input type=\"text\" class=\"form-control form-control-sm me-2 rename-field\"";
                echo "             value=\"$safeTitle\" style=\"max-width: 180px;\">";
                echo "      <button class=\"btn btn-sm btn-primary me-1 save-rename\" data-path=\"$relEscaped\">Rename</button>";
                echo "      <button class=\"btn btn-sm btn-secondary view-stats\" data-path=\"$relEscaped\">View Submissions</button>";
                echo "    </li>";
            }

            echo "  </ul>";
            echo "</div>";
        }
    } else {
        echo '<p class="text-muted">Modules directory not found.</p>';
    }
	
    ?>

    <!-- Floating Toolbar -->
    <div id="module-toolbar" class="d-none" style="
         position: fixed;
         top: 100px;
         right: 20px;
         background: #fff;
         border: 1px solid #ccc;
         padding: 0.5rem;
         box-shadow: 0 2px 6px rgba(0,0,0,0.1);
         z-index: 1000;
    ">
      <button id="btn-show" class="btn btn-sm btn-success mb-1">Show Module</button>
      <button id="btn-hide" class="btn btn-sm btn-danger">Hide Module</button>
    </div>

    <!-- Sections Modal -->
    <div id="sections-modal" class="d-none" style="
         position: fixed;
         top: 50%;
         left: 50%;
         transform: translate(-50%, -50%);
         background: #fff;
         border: 1px solid #ccc;
         padding: 1rem;
         max-width: 300px;
         max-height: 400px;
         overflow-y: auto;
         z-index: 1100;
    ">
      <h5>Select Sections</h5>
      <div id="sections-list" class="mb-3"></div>
      <button id="modal-ok" class="btn btn-sm btn-primary me-2">OK</button>
      <button id="modal-cancel" class="btn btn-sm btn-secondary">Cancel</button>
    </div>

  </main>
</div>

<script>
  // Expand/collapse module file list
  function toggleList(idKey) {
    const listEl = document.getElementById('list-' + idKey);
    const iconEl = document.getElementById('icon-' + idKey);
    if (!listEl) return;

    const isHidden = getComputedStyle(listEl).display === 'none';
    listEl.style.display = isHidden ? 'block' : 'none';

    if (iconEl?.classList.contains('bi')) {
      iconEl.classList.toggle('bi-chevron-down', !isHidden);
      iconEl.classList.toggle('bi-chevron-up', isHidden);
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const toolbar = document.getElementById('module-toolbar');
    const classSelect = document.getElementById('class-select');
    const selectedModules = new Set();

    // Toggle toolbar based on checkbox selection
    document.body.addEventListener('change', e => {
      if (!e.target.classList.contains('toggle-vis')) return;

      const anyChecked = [...document.querySelectorAll('.toggle-vis')]
                         .some(chk => chk.checked);
      toolbar.classList.toggle('d-none', !anyChecked);

      const path = e.target.dataset.path;
      if (e.target.checked) selectedModules.add(path);
      else selectedModules.delete(path);
    });

    // Fetch sections (from generate_Sections.php)
    async function fetchSections() {
      let url = 'get_sections.php'; // ✅ Make sure this path matches your server file
      if (classSelect && classSelect.value) {
        url += `?class_id=${encodeURIComponent(classSelect.value)}`;
      }

      try {
        const res = await fetch(url);
        const data = await res.json();

        if (data.error) {
          console.error('Server error:', data.error);
          return [];
        }
        return Array.isArray(data) ? data : [];
      } catch (err) {
        console.error('Fetch failed:', err);
        return [];
      }
    }

    // Open the section selector modal
    async function openSectionsModal(action) {
      const modal = document.getElementById('sections-modal');
      const list  = document.getElementById('sections-list');

      modal.classList.remove('d-none');
      list.innerHTML = '<p>Loading…</p>';

      const sections = await fetchSections();
      if (!sections.length) {
        list.innerHTML = '<p>No sections found.</p>';
      }
	  document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('sections-modal')?.classList.add('d-none');
  }
});

      list.innerHTML = sections.map(s =>
        `<div class="form-check">
           <input type="checkbox" class="form-check-input section-checkbox" value="${s.id}" id="sec-${s.id}">
           <label class="form-check-label" for="sec-${s.id}">${s.name}</label>
         </div>`
      ).join('');

      document.getElementById('modal-ok').onclick = () => {
        const chosen = [...list.querySelectorAll('.section-checkbox:checked')]
                         .map(i => i.value);
        console.log(`${action} modules`, [...selectedModules], '→ sections', chosen);
        modal.classList.add('d-none');
      };

      document.getElementById('modal-cancel').onclick = () => {
        modal.classList.add('d-none');
      };
    }

    // Button event handlers
    document.getElementById('btn-show')?.addEventListener('click', () => openSectionsModal('show'));
    document.getElementById('btn-hide')?.addEventListener('click', () => openSectionsModal('hide'));
  });
</script>

<script src="../assets/js/student.js"></script>
<?php include('partials/_footer.php'); ?>
