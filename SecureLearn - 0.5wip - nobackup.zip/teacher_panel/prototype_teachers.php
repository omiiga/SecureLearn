<?php include('partials/_header.php') ?>
<!-- Sidebar -->
<?php include('partials/_sidebar.php') ?>
<input type="hidden" value="2" id="checkFileName">
<!-- End of Sidebar -->

<!-- Main Content -->
<div class="content">
    <!-- Navbar -->
    <?php include("partials/_navbar.php"); ?>
    <!-- End of Navbar -->
</div>

  <main class="module-wrapper">
    <h2><center>Manage Modules</center></h2>

    <?php
      $modulesPath = realpath(__DIR__ . '/../modules');
    if ($modulesPath && is_dir($modulesPath)) {
        $folders = scandir($modulesPath);
        foreach ($folders as $folder) {
            if ($folder === '.' || $folder === '..') continue;
            $folderPath = $modulesPath . DIRECTORY_SEPARATOR . $folder;
            if (is_dir($folderPath)) {
                echo "<div class='folder'>";
                echo "<div class='folder-name' onclick=\"toggleList('$folder')\">$folder</div>";
                echo "<ul class='file-list' id='list-$folder'>";
                $files = scandir($folderPath);
                foreach ($files as $file) {
                    if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
                        $relPath = "../modules/$folder/$file";
                        echo "<li>$file <button class='launch-btn' onclick=\"openModule('$relPath')\">Start Module</button></li>";
                    }
                }
                echo "</ul></div>";
            }
        }
    } else {
        echo '<p>Modules directory not found.</p>';
    }
  ?>
    ?>
  </main>
</div>

<div id="module-window-container" class="module-window-container" style="display: none;">
  <div class="title-bar">
    <span id="module-title" class="module-title"></span>
    <div class="window-controls">
      <button class="control-btn minimize-btn" onclick="minimizeModule()">
        <span class="material-icons-sharp">minimize</span>
      </button>
      <button class="control-btn close-btn" onclick="closeModule()">
        <span class="material-icons-sharp">close</span>
      </button>
    </div>
  </div>
  <iframe id="module-iframe" class="module-iframe" src=""></iframe>
</div>

<div id="popup-bg" class="popup-bg" onclick="closeModule()"></div>
<div id="minimized-modules-container" class="minimized-modules-container"></div>

<div id="message-box-overlay" class="message-box-overlay">
  <div class="message-box">
    <h3 id="message-box-title"></h3>
    <p id="message-box-text"></p>
    <button id="message-box-ok-btn">OK</button>
  </div>
</div>

<script src="app.js"></script>
<script src="../assets/js/student.js"></script>
<?php include('partials/_footer.php'); ?>
</body>
</html>
