<?php include("../assets/noSessionRedirect.php"); ?>
<?php include("./verifyRoleRedirect.php"); ?>

<!DOCTYPE html>
<html lang="en">
<header>
    <div class="logo" title="SecureLearn">
        <img src="./images/logo.png" alt="">
        <h2>Secure<span class="danger">Learn</span></h2>
    </div>
    <div class="navbar">
        <a href="index.php"><span class="material-icons-sharp">home</span><h3>Home</h3></a>
        <a href="timetable.php"><span class="material-icons-sharp">today</span><h3>Time Table</h3></a>
        <a href="exam.php"><span class="material-icons-sharp">grid_view</span><h3>Examination</h3></a>
        <a href="workspace.php"><span class="material-icons-sharp">description</span><h3>Syllabus</h3></a>
        <a href="Modules.php"><span class="material-icons-sharp">description</span><h3>Modules</h3></a>
        <a href="password.php"><span class="material-icons-sharp">password</span><h3>Change Password</h3></a>
        <a href="logout.php"><span class="material-icons-sharp">logout</span><h3>Logout</h3></a>
    </div>
    <div id="profile-btn" style="display: none;">
        <span class="material-icons-sharp">person</span>
    </div>
    <div class="theme-toggler">
        <span class="material-icons-sharp active">light_mode</span>
        <span class="material-icons-sharp">dark_mode</span>
    </div>
</header>
<br><br><br><br>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modules</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="shortcut icon" href="../Resources/hmbct.png" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/oranbyte-google-translator.css">
    <script src="../js/oranbyte-google-translator.js" defer></script>
    <style>
        /* Base Body Styles - these are crucial for general text color */
        body {
            background-color: #f6f6f9; /* Default light background */
            color: #363949; /* Default light mode text color */
            transition: background-color 0.3s ease, color 0.3s ease; /* dark animation anes */
            font-family: 'Inter', sans-serif; /* Using Inter font */
            margin: 0;
            padding: 0;
        }

        body.dark-mode {
            background-color: #181a1e; /* Dark mode background */
            color: #edeffd; /* Dark mode text color */
        }

        /* Navbar Link Colors - important for readability */
        .navbar a {
            color: #363949; /* Default link color in light mode */
            transition: color 0.3s ease;
        }

        body.dark-mode .navbar a {
            color: #edeffd; /* Link color in dark mode */
        }

        /* Light Mode Styles (Default) */
        .module-wrapper {
            margin: auto;
            max-width: 800px;
            padding: 20px;
            background-color: #e0e0e0; /* Explicit light background */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease, color 0.3s ease;
            margin-top: 50px; /* Adjust for header */
        }
        .module-wrapper h2 {
            color: #333; /* Default light mode color for title */
            transition: color 0.3s ease; /* Smooth transition for h2 color */
        }
        .folder {
            margin-bottom: 10px;
        }
        .folder-name {
            font-weight: bold;
            cursor: pointer;
            padding: 10px;
            background: #ccc; /* Light background for folders */
            border-radius: 5px;
            color: #333; /* Dark text for folders */
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .file-list {
            display: none;
            margin-left: 20px;
            margin-top: 5px;
            color: #333; /* Dark text for file list items in light mode */
            transition: color 0.3s ease; /* Smooth transition for file list color */
        }
        .file-list li {
            margin: 8px 0;
            list-style: none;
            color: #333; /* Default text color for list items in light mode */
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .file-list li span { /* Added a specific rule for the span inside list items */
            color: #333; /* Ensure span text is dark in light mode */
            transition: color 0.3s ease;
            flex-grow: 1; /* Allow filename to take available space */
        }
        .launch-btn {
            background-color: #8f99ed;
            color: black;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.95rem;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.1s ease;
        }
        .launch-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(54,57,73,0.2);
        }
        .launch-btn:active {
            transform: translateY(0);
            box-shadow: none;
        }

        /* Dark Mode Styles - triggered by a class on the body */
        body.dark-mode .module-wrapper {
            background-color: #2f3d4a; /* Dark background for the module container */
        }
        body.dark-mode .module-wrapper h2 {
            color: #f0f0f0; /* Light text for "Available Modules" title */
        }
        body.dark-mode .folder-name {
            background: #25303a; /* Darker background for folders */
            color: #d4d4d4; /* Lighter text for folder names */
        }
        body.dark-mode .file-list {
            color: #cccccc; /* Lighter text for file list items */
        }
        body.dark-mode .file-list li { /* Ensure list items explicitly get dark mode color */
            color: #cccccc;
        }
        body.dark-mode .file-list li span { /* Ensure span text explicitly gets dark mode color */
            color: #cccccc;
        }
        body.dark-mode .launch-btn {
            background-color: #5a7d9a; /* Darker button for dark mode */
            color: #f0f0f0;
        }

        /* --- Windows-like UI for Modules (Fullscreen in-page) --- */
        .module-window-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: var(--window-bg-color, #f0f2f5); /* Light default */
            border: 1px solid var(--window-border-color, #ccc);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            overflow: hidden; /* Prevent iframe scrollbars from affecting parent */
            border-radius: 8px; /* Rounded corners for the window */
        }

        body.dark-mode .module-window-container {
            --window-bg-color: #2f3d4a;
            --window-border-color: #444;
            color: #edeffd;
        }

        .title-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            background-color: var(--title-bar-bg, #007bff); /* Blue default */
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
            border-bottom: 1px solid var(--title-bar-border, #0056b3);
            cursor: default; /* Not draggable, but indicates an active area */
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            user-select: none; /* Prevent text selection */
        }

        body.dark-mode .title-bar {
            --title-bar-bg: #1a2a3a; /* Darker blue for dark mode */
            --title-bar-border: #0e1e2b;
        }

        .module-title {
            flex-grow: 1;
            text-align: left;
            padding-right: 10px; /* Space before controls */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .window-controls {
            display: flex;
            gap: 5px;
        }

        .control-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 3px 6px;
            border-radius: 4px;
            transition: background-color 0.2s ease, transform 0.1s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1; /* Adjust to center material icon */
        }

        .control-btn:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-1px);
        }
        .control-btn:active {
            transform: translateY(0);
        }

        .close-btn:hover {
            background-color: #dc3545; /* Red for close button on hover */
        }
        body.dark-mode .close-btn:hover {
            background-color: #88333f;
        }

        .module-iframe {
            flex-grow: 1; /* Take all available space below the title bar */
            width: 100%;
            height: 100%; /* Will be managed by flex-grow */
            border: none;
            background-color: white; /* Ensure iframe background is white by default */
        }
        body.dark-mode .module-iframe {
            background-color: #1e2833; /* Darker background for iframe in dark mode */
        }

        /* Background overlay */
        .popup-bg {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }

        /* Minimized bubble styles */
        .minimized-modules-container {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
            z-index: 1001; /* Above everything else */
        }

        .minimized-bubble {
            background-color: var(--bubble-bg, #007bff);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            transition: background-color 0.2s ease, transform 0.1s ease;
        }
        .minimized-bubble:hover {
            background-color: var(--bubble-bg-hover, #0056b3);
            transform: translateY(-2px);
        }
        .minimized-bubble:active {
            transform: translateY(0);
        }
        body.dark-mode .minimized-bubble {
            --bubble-bg: #1a2a3a;
            --bubble-bg-hover: #0e1e2b;
        }

        /* Custom Message Box Styles (instead of alert) */
        .message-box-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000; /* Higher than other popups */
            display: none; /* Hidden by default */
        }

        .message-box {
            background-color: var(--msg-box-bg, #fff);
            color: var(--msg-box-text, #333);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
            max-width: 400px;
            text-align: center;
            position: relative;
        }

        body.dark-mode .message-box {
            --msg-box-bg: #2f3d4a;
            --msg-box-text: #edeffd;
        }

        .message-box h3 {
            margin-top: 0;
            color: var(--msg-box-heading, #007bff);
            margin-bottom: 15px;
        }
        body.dark-mode .message-box h3 {
            --msg-box-heading: #5a7d9a;
        }

        .message-box p {
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .message-box button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.2s ease;
        }

        .message-box button:hover {
            background-color: #0056b3;
        }
        body.dark-mode .message-box button {
            background-color: #5a7d9a;
        }
        body.dark-mode .message-box button:hover {
            background-color: #4a6d8a;
        }

    </style>
</head>
<body>
<main class="module-wrapper">
    <h2 style="text-align:center;">Available Modules</h2>
    <?php
    $modulesPath = realpath(__DIR__ . '/../modules');
    if ($modulesPath && is_dir($modulesPath)) {
        $folders = scandir($modulesPath);
        foreach ($folders as $folder) {
            // Exclude '.' and '..' and the 'Resources' folder
            if ($folder === '.' || $folder === '..' || $folder === 'Resources') continue;

            $folderPath = $modulesPath . DIRECTORY_SEPARATOR . $folder;
            if (is_dir($folderPath)) {
                echo "<div class='folder'>";
                echo "<div class='folder-name' onclick=\"toggleList('".htmlspecialchars($folder, ENT_QUOTES)."')\">".htmlspecialchars($folder)."</div>";
                echo "<ul class='file-list' id='list-".htmlspecialchars($folder, ENT_QUOTES)."'>";
                $files = scandir($folderPath);
                foreach ($files as $file) {
                    if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
                        $relPath = "../modules/".urlencode($folder)."/".urlencode($file);
                        $moduleTitle = htmlspecialchars(pathinfo($file, PATHINFO_FILENAME));
                        echo "<li><span>{$moduleTitle}</span>"
                           . " <button class='launch-btn' onclick=\"openModule('{$relPath}', '{$moduleTitle}', 'fullscreen')\">Open Fullscreen</button>"
                           . " <button class='launch-btn launch-new-tab-btn' onclick=\"openModule('{$relPath}', '{$moduleTitle}', 'newtab')\">Open in New Tab</button>"
                           . "</li>";
                    }
                }
                echo "</ul></div>";
            }
        }
    } else {
        echo '<p>Modules directory not found.</p>';
    }
    ?>
</main>

<!-- Windows-like UI for Modules (Fullscreen in-page) -->
<div id="module-window-container" class="module-window-container" style="display: none;">
    <div class="title-bar">
        <span id="module-title" class="module-title">Module Title</span>
        <div class="window-controls">
            <button class="control-btn minimize-btn" title="Minimize" onclick="minimizeModule()">
                <span class="material-icons-sharp">remove</span>
            </button>
            <button class="control-btn close-btn" title="Close" onclick="closeModule()">
                <span class="material-icons-sharp">close</span>
            </button>
        </div>
    </div>
    <iframe id="module-iframe" class="module-iframe"></iframe>
</div>

<!-- Container for minimized module bubbles -->
<div id="minimized-modules-container" class="minimized-modules-container"></div>

<!-- Background overlay for fullscreen module -->
<div id="popup-bg" class="popup-bg" onclick="closeModule()"></div>

<!-- Custom Message Box -->
<div id="message-box-overlay" class="message-box-overlay">
    <div class="message-box">
        <h3 id="message-box-title"></h3>
        <p id="message-box-text"></p>
        <button onclick="hideMessageBox()">OK</button>
    </div>
</div>

<script>
    // Global state for the currently open module
    let currentModule = {
        url: '',
        title: '',
        isMinimized: false,
        isOpen: false
    };

    /**
     * Shows a custom message box instead of native alert().
     * @param {string} title - The title of the message box.
     * @param {string} message - The message to display.
     */
    function showMessageBox(title, message) {
        document.getElementById('message-box-title').textContent = title;
        document.getElementById('message-box-text').textContent = message;
        document.getElementById('message-box-overlay').style.display = 'flex';
    }

    /**
     * Hides the custom message box.
     */
    function hideMessageBox() {
        document.getElementById('message-box-overlay').style.display = 'none';
    }

    /**
     * Toggles the display of a file list (folder content).
     * @param {string} id - The ID of the folder (used to construct the list ID).
     */
    function toggleList(id) {
        const list = document.getElementById('list-' + id);
        if (list.style.display === 'block') {
            list.style.display = 'none';
        } else {
            list.style.display = 'block';
        }
    }

    /**
     * Opens a module based on the specified mode (fullscreen in-page or new tab).
     * @param {string} url - The URL of the module to open.
     * @param {string} title - The title of the module.
     * @param {'fullscreen'|'newtab'} mode - The display mode ('fullscreen' or 'newtab').
     */
    function openModule(url, title, mode) {
        if (mode === 'fullscreen') {
            openModuleFullscreen(url, title);
        } else if (mode === 'newtab') {
            openModuleNewTab(url, title);
        }
    }

    /**
     * Opens a module in a fullscreen, Windows-like window within the current page.
     * @param {string} url - The URL of the module.
     * @param {string} title - The title of the module.
     */
    function openModuleFullscreen(url, title) {
        const container = document.getElementById('module-window-container');
        const iframe = document.getElementById('module-iframe');
        const moduleTitleSpan = document.getElementById('module-title');
        const bg = document.getElementById('popup-bg');
        const minimizedContainer = document.getElementById('minimized-modules-container');

        // Close any currently open or minimized module before opening a new one
        closeModule();

        // Update the global module state
        currentModule.url = url;
        currentModule.title = title;
        currentModule.isOpen = true;
        currentModule.isMinimized = false;

        // Set content and display the window
        moduleTitleSpan.textContent = title;
        iframe.src = url;
        container.style.display = 'flex'; /* Use flex to manage title bar and iframe */
        bg.style.display = 'block';
        minimizedContainer.innerHTML = ''; // Ensure no old bubbles remain
    }

    /**
     * Opens a module in a new browser tab with specific features.
     * Note: Modern browsers restrict control over pop-up window positioning and resizability.
     * @param {string} url - The URL of the module.
     * @param {string} title - The title of the module (used for window name).
     */
    function openModuleNewTab(url, title) {
        // Define window features for a fixed-size, non-resizable pop-up-like window
        // These are hints to the browser; actual behavior may vary.
        const windowFeatures = 'width=1024,height=768,resizable=no,scrollbars=yes,status=no,toolbar=no,menubar=no,location=no';
        const newWindow = window.open(url, '_blank', windowFeatures);

        if (newWindow) {
            newWindow.focus();
            showMessageBox('Module Opened', 'The module has been opened in a new tab/window. Please note that browser security policies may restrict exact window size, position, and movability.');
        } else {
            // Fallback if the pop-up was blocked by the browser
            showMessageBox('Pop-up Blocked', 'Please allow pop-ups for this site to open modules in a new tab.');
        }
    }

    /**
     * Minimizes the currently open fullscreen module to a bubble.
     */
    function minimizeModule() {
        const container = document.getElementById('module-window-container');
        const minimizedContainer = document.getElementById('minimized-modules-container');

        if (!currentModule.isOpen || currentModule.isMinimized) return; // Only minimize if open and not already minimized

        container.style.display = 'none';
        currentModule.isMinimized = true;

        // Create and show a bubble representing the minimized module
        const bubble = document.createElement('div');
        bubble.className = 'minimized-bubble';
        // Using a generic folder icon from Material Icons Sharp
        bubble.innerHTML = `<span class="material-icons-sharp">folder</span><span>${currentModule.title}</span>`;
        bubble.onclick = restoreModule; // Restore when bubble is clicked
        minimizedContainer.appendChild(bubble);

        // Hide the background overlay when minimized
        document.getElementById('popup-bg').style.display = 'none';
    }

    /**
     * Restores a minimized module to its fullscreen state within the page.
     */
    function restoreModule() {
        const container = document.getElementById('module-window-container');
        const minimizedContainer = document.getElementById('minimized-modules-container');

        if (!currentModule.isOpen || !currentModule.isMinimized) return; // Only restore if open and minimized

        container.style.display = 'flex'; // Restore display
        minimizedContainer.innerHTML = ''; // Remove the bubble from the container
        currentModule.isMinimized = false;

        // Show the background overlay when restored
        document.getElementById('popup-bg').style.display = 'block';
    }

    /**
     * Closes the currently open (or minimized) fullscreen module.
     * Resets the UI and module state.
     */
    function closeModule() {
        const container = document.getElementById('module-window-container');
        const iframe = document.getElementById('module-iframe');
        const bg = document.getElementById('popup-bg');
        const minimizedContainer = document.getElementById('minimized-modules-container');

        // Clear iframe content and hide the container
        iframe.src = '';
        container.style.display = 'none';
        bg.style.display = 'none';
        minimizedContainer.innerHTML = ''; // Ensure any bubble is cleared

        // Reset the global module state
        currentModule = {
            url: '',
            title: '',
            isMinimized: false,
            isOpen: false
        };
    }

    document.addEventListener('DOMContentLoaded', () => {
        const themeToggler = document.querySelector('.theme-toggler');
        const body = document.body;
        const lightModeIcon = themeToggler.querySelector('.light_mode');
        const darkModeIcon = themeToggler.querySelector('.dark_mode');

        // Function to apply theme and update active icons
        const applyTheme = (theme) => {
            if (theme === 'dark') {
                body.classList.add('dark-mode');
                lightModeIcon.classList.remove('active');
                darkModeIcon.classList.add('active');
            } else {
                body.classList.remove('dark-mode');
                lightModeIcon.classList.add('active');
                darkModeIcon.classList.remove('active');
            }
            localStorage.setItem('theme', theme); // Always save the chosen theme
        };

        // --- Initial Theme Load Logic ---
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            // If a theme is explicitly saved, use it. This prevents system preference from overriding.
            applyTheme(savedTheme);
        } else {
            // Fallback to system preference if no theme is saved (optional, currently not implemented)
            // For now, if no theme is saved, it defaults to light mode as per CSS.
        }

        // --- Theme Toggler Click Handler ---
        themeToggler.addEventListener('click', () => {
            // Toggle the theme based on the current state of the body class
            if (body.classList.contains('dark-mode')) {
                applyTheme('light');
            } else {
                applyTheme('dark');
            }
        });
    });
</script>
<script src="app.js" defer></script>
</body>
</html>
