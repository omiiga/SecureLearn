
<?php include("../assets/noSessionRedirect.php"); ?>
<?php include("./verifyRoleRedirect.php"); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="shortcut icon" href="./images/logo.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/oranbyte-google-translator.css">
    <script src="../js/oranbyte-google-translator.js"></script>
</head>
<body>
    <header>
        <div class="logo" title="SecureLearn">
            <img src="./images/logo.png" alt="">
            <h2>Secure<span class="danger">Learn</span></h2>
        </div>
      <div style="
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    overflow-x: auto;
    white-space: nowrap;
">
    <div class="navbar" style="
        display: inline-flex;
        gap: 1rem;
    ">

        <a href="timetable.php" class="active" onclick="timeTableAll()" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">today</span>
            <h3 style="margin: 0; font-size: 1rem;">Time Table</h3>
        </a>
		        <a href="index.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">home</span>
            <h3 style="margin: 0; font-size: 1rem;">Home</h3>
        </a>
        <a href="timetable.php" class="active" onclick="timeTableAll()" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">today</span>
            <h3 style="margin: 0; font-size: 1rem;">Time Table</h3>
        </a>
        <a href="exam.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">grid_view</span>
            <h3 style="margin: 0; font-size: 1rem;">Examination</h3>
        </a>
        <a href="workspace.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Syllabus</h3>
        </a>
        <a href="modules.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Modules</h3>
        </a>
        <a href="password.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">password</span>
            <h3 style="margin: 0; font-size: 1rem;">Change Password</h3>
        </a>

    </div>

 


</div>
   <div id="profile-btn" style="display: block; text-align: center;">
        <span class="material-icons-sharp">person</span>
    </div>
    <div class="theme-toggler" style="
        display: inline-flex;
        gap: 0.25rem;
        text-align: center;
    ">
        <span class="material-icons-sharp active">light_mode</span>
        <span class="material-icons-sharp">dark_mode</span>
    </div>
	        <a href="logout.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">logout</span>
            <h3 style="margin: 0; font-size: 1rem;">Logout</h3>
        </a>
        
    </header>

    <main style="margin: 0;">
        <div class="timetable active" id="timetable">
            <div>
                <span id="prevDay">&lt;</span>
                <h2>Today's Timetable</h2>
                <span id="nextDay">&gt;</span>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Subject</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </main>

</body>

<script src="timeTable.js"></script>
<script src="app.js"></script>
</html>