<?php include("../assets/noSessionRedirect.php"); ?>
<?php include("./verifyRoleRedirect.php"); ?>
<?php include("partials/_navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
         <header>
        <div class="logo" title="SecureLearn">
            <img src="./images/logo.png" alt="">
            <h2>Secure<span class="danger">Learn</span></h2>
        </div>
      <div style="
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    gap: 1rem;
    overflow-x: auto;
    white-space: nowrap;
">
    <div class="navbar" style="
        display: inline-flex;
        gap: 1rem;
    ">

        <a href="" class="" onclick="" style="">
            <span class=""></span>
            <h3 style=""></h3>
        </a>
		        <a href="" class="" onclick="" style="">
            <span class=""></span>
            <h3 style=""></h3>
        </a>

		<a href="timetable.php" onclick="timeTableAll()" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">today</span>
            <h3 style="margin: 0; font-size: 1rem;">Time Table</h3>
        </a>
        <a href="exam.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">grid_view</span>
            <h3 style="margin: 0; font-size: 1rem;">Examination</h3>
        </a>
        <a href="workspace.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Syllabus</h3>
        </a>
        <a href="modules.php"  class="active" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Modules</h3>
        </a>
        <a href="password.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">password</span>
            <h3 style="margin: 0; font-size: 1rem;">Change Password</h3>
        </a>

    </div>

 


</div>
   <div id="profile-btn" style="display: block; text-align: center;">
        <span class="material-icons-sharp">person</span>
    </div>
    <div class="theme-toggler" style="
        display: inline-flex;
        gap: 0.25rem;
        text-align: center;
    ">
        <span class="material-icons-sharp active">light_mode</span>
        <span class="material-icons-sharp">dark_mode</span>
    </div>
	        <a href="logout.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">logout</span>
            <h3 style="margin: 0; font-size: 1rem;">Logout</h3>
        </a>
        
    </header>

<script>
  const navbar = document.getElementById('main-navbar');
  document.getElementById('nav-left').addEventListener('click', () => {
    navbar.scrollLeft -= 100;
  });
  document.getElementById('nav-right').addEventListener('click', () => {
    navbar.scrollLeft += 100;
  });
</script>
	<br><br><br><br>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XSS 1</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="shortcut icon" href="../Resources/hmbct.png" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/oranbyte-google-translator.css">
    <script src="../js/oranbyte-google-translator.js"></script>
<style>
  /* -------------------------
     GLOBAL STYLES
     ------------------------- */
	 	:root {
    --header-height: 56px;
    --padding-h: 16px;
  }

  
  body {
    margin: 0;
    padding: 0;
    background-color: #fafafa;
    color: #222;
    font-family: sans-serif;
    transition: background-color 0.3s ease, color 0.3s ease;
  }


  /* -------------------------
     MODULE‐WRAPPER STYLES
     ------------------------- */
  .module-wrapper {
    margin: auto;
    max-width: 800px;
    padding: 20px;
    background-color: #e0e0e0;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  .module-wrapper h2.module-title {
    text-align: center;
    color: #333;
  }

  .folder {
    margin-bottom: 10px;
  }

  .folder-name {
    font-weight: bold;
    cursor: pointer;
    padding: 10px;
    background: #ccc;
    border-radius: 5px;
    color: #333;
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  .file-list {
    display: none;
    margin-left: 20px;
    margin-top: 5px;
    color: #333;
  }

  .file-list li {
    margin: 8px 0;
    list-style: none;
  }

  .launch-btn {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.95rem;
    transition: background-color 0.3s ease;
  }

  .popup-frame {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 80%;
    height: 80%;
    border: none;
    z-index: 1000;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.5);
  }

  #popup-bg {
    display: none;
    position: fixed;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 999;
  }

  /* -------------------------
     GLOBAL DARK MODE
     ------------------------- */
  body.dark-mode {
    background-color: #121212;
    color: #e0e0e0;
  }

  body.dark-mode header,
  body.dark-mode footer {
    background-color: #1e1e1e;
    color: #e0e0e0;
  }

  /* -------------------------
     MODULE WRAPPER DARK MODE
     ------------------------- */
  body.dark-mode .module-wrapper {
    background-color: #2f3d4a;
    color: #e0e0e0;
  }

  body.dark-mode .module-wrapper h2.module-title {
    color: #f0f0f0;
  }

  body.dark-mode .module-wrapper .folder-name {
    background: #25303a;
    color: #d4d4d4;
  }

  body.dark-mode .module-wrapper .file-list {
    color: #cccccc;
  }

  body.dark-mode .module-wrapper .launch-btn {
    background-color: #1a73e8;
  }
</style>
</head>
<body>
<br><br><br>
<main class="module-wrapper">
  <h2 class="module-title">Available Modules</h2>
  <?php
    $modulesPath = realpath(__DIR__ . '/../modules');
    if ($modulesPath && is_dir($modulesPath)) {
        $folders = scandir($modulesPath);
        foreach ($folders as $folder) {
            if ($folder === '.' || $folder === '..') continue;
            $folderPath = $modulesPath . DIRECTORY_SEPARATOR . $folder;
            if (is_dir($folderPath)) {
                echo "<div class='folder'>";
                echo "<div class='folder-name' onclick=\"toggleList('$folder')\">$folder</div>";
                echo "<ul class='file-list' id='list-$folder'>";
                $files = scandir($folderPath);
                foreach ($files as $file) {
                    if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
                        $relPath = "../modules/$folder/$file";
                        echo "<li>$file <button class='launch-btn' onclick=\"openModule('$relPath')\">Start Module</button></li>";
                    }
                }
                echo "</ul></div>";
            }
        }
    } else {
        echo '<p>Modules directory not found.</p>';
    }
  ?>
</main>

<div id="popup-bg" onclick="closePopup()"></div>
<iframe id="popup-frame" class="popup-frame"></iframe>

<script>

  // Toggle folder lists
  function toggleList(id) {
    const list = document.getElementById('list-' + id);
    list.style.display = (list.style.display === 'block') ? 'none' : 'block';
  }

  // Open module in popup iframe
function syncTheme() {
  const isDark = document.body.classList.contains('dark-mode');
  const frame = document.getElementById('popup-frame');
  const controls = document.getElementById('window-controls');
  const minNotif = document.getElementById('min-notif');

  if (frame) {
    frame.style.backgroundColor = isDark ? '#2f3d4a' : '#ffffff';
  }
  if (controls) {
    controls.style.backgroundColor = isDark ? '#25303a' : '#f0f0f0';
    controls.querySelectorAll('button').forEach(btn => {
      btn.style.color           = isDark ? '#e0e0e0' : '#333';
      btn.style.backgroundColor = 'transparent';
      btn.style.border          = 'none';
    });
  }
  if (minNotif) {
    minNotif.style.backgroundColor = '#FFBF00';
    minNotif.style.color           = '#000';
    minNotif.style.opacity         = '1';
  }
}

// Open module with window‑controls and live theme sync
function syncTheme() {
  const isDark = document.body.classList.contains('dark-mode');
  const frame    = document.getElementById('popup-frame');
  const controls = document.getElementById('window-controls');
  const minNotif = document.getElementById('min-notif');

  if (frame) {
    frame.style.backgroundColor = isDark ? '#2f3d4a' : '#ffffff';
  }
  if (controls) {
    controls.style.backgroundColor = isDark ? '#25303a' : '#f0f0f0';
    controls.querySelectorAll('button').forEach(btn => {
      btn.style.color           = isDark ? '#e0e0e0' : '#333';
      btn.style.backgroundColor = 'transparent';
      btn.style.border          = 'none';
    });
  }
  if (minNotif) {
    minNotif.style.backgroundColor = '#FFBF00';
    minNotif.style.color           = '#000';
    minNotif.style.opacity         = '1';
  }
}

// Open module + adaptive tutorial
function openModule(url) {
  const frame  = document.getElementById('popup-frame');
  const bg     = document.getElementById('popup-bg');
  let controls = document.getElementById('window-controls');
  let minNotif = null;
  let observer = null;

  // create controls if missing
  if (!controls) {
    controls = document.createElement('div');
    controls.id = 'window-controls';
    Object.assign(controls.style, {
      position: 'fixed',
      top: '67px',
      right: '140px',
      padding: '5px',
      borderRadius: '30px',
      display: 'flex',
      gap: '15px',
      zIndex: 1002
    });
    controls.innerHTML = `
      <button id="min-btn" title="Minimize">—</button>
      <button id="fs-btn"  title="Fullscreen">⛶</button>
      <button id="close-btn" title="Close">✕</button>
    `;
    document.body.appendChild(controls);

    controls.querySelector('#min-btn').addEventListener('click', () => {
      frame.style.display    = 'none';
      bg.style.display       = 'none';
      controls.style.display = 'none';
      showMinNotif();
      if (observer) observer.disconnect();
    });
    controls.querySelector('#fs-btn').addEventListener('click', () => {
      if (!document.fullscreenElement) frame.requestFullscreen?.();
      else document.exitFullscreen?.();
    });
    controls.querySelector('#close-btn').addEventListener('click', () => {
      if (confirm('Are you sure you want to close this module?')) {
        closePopup();
        controls.style.display = 'none';
        if (observer) observer.disconnect();
        const n = document.getElementById('min-notif');
        if (n) n.remove();
        minNotif = null;
      }
    });
  } else {
    controls.style.display = 'flex';
  }

  // minimized notification
  function showMinNotif() {
    if (!minNotif) {
      minNotif = document.createElement('div');
      minNotif.id = 'min-notif';
      minNotif.textContent = '⚠️ Unfinished module minimized';
      Object.assign(minNotif.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        padding: '10px 15px',
        borderRadius: '4px',
        boxShadow: '0 2px 6px rgba(0,0,0,0.3)',
        cursor: 'pointer',
        transition: 'opacity 0.3s',
        zIndex: 1003
      });
      minNotif.addEventListener('click', () => {
        frame.style.display    = 'block';
        bg.style.display       = 'block';
        controls.style.display = 'flex';
        minNotif.remove();
        minNotif = null;
        syncTheme();
      });
      document.body.appendChild(minNotif);
    }
    syncTheme();
  }

  // instance meter: 5s tutorial with full-screen dim + circular highlight
  function showInstanceMeter() {
    const isDark = document.body.classList.contains('dark-mode');
    const rect   = controls.getBoundingClientRect();

    // full-screen overlay with circular "hole" over controls
    const overlay = document.createElement('div');
    Object.assign(overlay.style, {
      position: 'fixed',
      top: 0, left: 0,
      width: '100%', height: '100%',
      backgroundColor: 'rgba(0,0,0,0.7)',
      clipPath: `circle(${(rect.width + 9000)/2}px at ${rect.left + rect.width/2}px ${rect.top + rect.height/2}px)`,
      zIndex: 1001,
      transition: 'clip-path 0.7s ease'
    });
    document.body.appendChild(overlay);

    // tutorial bubble
    const bubble = document.createElement('div');
    const bgCol  = isDark ? '#2f3d4a' : '#ffffff';
    const txtCol = isDark ? '#e0e0e0' : '#333';
    Object.assign(bubble.style, {
      position: 'absolute',
      maxWidth: '240px',
      padding: '14px 16px',
      borderRadius: '8px',
      backgroundColor: bgCol,
      color: txtCol,
      boxShadow: '0 6px 16px rgba(0,0,0,0.2)',
      fontSize: '14px',
      lineHeight: '1.5',
      left: `${Math.max(10, rect.left - 260)}px`,
      top: `${rect.top}px`,
      zIndex: 1002,
      opacity: '0',
      transition: 'opacity 0.9s ease'
    });
    bubble.innerHTML = `
      <strong><b><center>Toolbar guide</center></b></strong>
	  <br>
      <em> —  </em><right> Minimize module </right><br>
	  <br>
      <em> ⛶  </em> Fullscreen<br>
	  <br>
      <em> ✕  </em> Close<br>
	  <br>
      <center>Closing in <span id="meter-count">3</span>s...</center>
    `;
    document.body.appendChild(bubble);

    // arrow pointer
    const arrow = document.createElement('div');
    Object.assign(arrow.style, {
      position: 'absolute',
      width: '0', height: '0',
      borderLeft: '8px solid transparent',
      borderRight: '8px solid transparent',
      borderTop: `8px solid ${bgCol}`,
      left: `${Math.max(10, rect.left - 244)}px`,
      top: `${rect.top + 24}px`,
      zIndex: 1002,
      opacity: '0',
      transition: 'opacity 0.4s ease'
    });
    document.body.appendChild(arrow);

    // fade in bubble & arrow
    requestAnimationFrame(() => {
      bubble.style.opacity = '1';
    });

    // countdown & cleanup
    let count = 5;
    const interval = setInterval(() => {
      bubble.querySelector('#meter-count').textContent = --count;
      if (count <= 0) {
        clearInterval(interval);
        overlay.remove();
        bubble.remove();
        arrow.remove();
      }
    }, 1000);
  }

  // show module & tutorial
  frame.src           = url;
  frame.style.display = 'block';
  bg.style.display    = 'block';
  syncTheme();

  // live theme sync
  observer = new MutationObserver(muts => {
    muts.forEach(m => {
      if (m.attributeName === 'class') syncTheme();
    });
  });
  observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });

  showInstanceMeter();
}

// Dark mode toggle handler
function setDarkMode(on) {
  document.body.classList.toggle('dark-mode', on);
  document.querySelector('.module-wrapper')
          .classList.toggle('dark-mode', on);
  localStorage.setItem('darkMode', on);
  updateTogglerIcons(on);
  syncTheme();
}
  function closePopup() {
    const frame = document.getElementById('popup-frame');
    const bg    = document.getElementById('popup-bg');
    frame.src           = '';
    frame.style.display = 'none';
    bg.style.display    = 'none';
  }

  // —— DARK MODE LOGIC —— //

  // Apply dark-mode class to page, module-wrapper, and iframe content
  function setDarkMode(on) {
    // 1) parent page
    document.body.classList.toggle('dark-mode', on);
    document.querySelector('.module-wrapper').classList.toggle('dark-mode', on);

    // 2) iframe content window, if loaded
    const frame = document.getElementById('popup-frame');

    localStorage.setItem('darkMode', on);
    updateTogglerIcons(on);
  }

  // When a module loads, apply current theme

  // Update icons in the toggle switch
  function updateTogglerIcons(isDark) {
    const [lightIcon, darkIcon] = document.querySelectorAll('.theme-toggler .material-icons-sharp');
    if (isDark) {
      lightIcon.classList.add('active');
      darkIcon.classList.remove('active');
    }
  }

  // Hook up your existing theme switcher
  document.querySelector('.theme-toggler').addEventListener('click', () => {
    const nowDark = document.body.classList.contains('dark-mode');
    setDarkMode(!nowDark);
  });
</script>


<script src="app.js"></script>
</body>
</html>
