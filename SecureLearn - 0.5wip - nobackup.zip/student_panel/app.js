
document.addEventListener("DOMContentLoaded", () => {
  const sideMenu = document.querySelector("aside");
  const profileBtn = document.querySelector("#profile-btn");
  const themeToggler = document.querySelector(".theme-toggler");
  const nextDay = document.getElementById("nextDay");
  const prevDay = document.getElementById("prevDay");

  profileBtn?.addEventListener("click", () => {
    sideMenu?.classList.toggle("active");
  });

  window.addEventListener("scroll", () => {
    sideMenu?.classList.remove("active");
    document.querySelector("header")?.classList.toggle("active", window.scrollY > 0);
  });

  themeToggler?.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const spans = themeToggler.querySelectorAll("span");
    spans[0]?.classList.toggle("active");
    spans[1]?.classList.toggle("active");
  });

  const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const timetableData = {
    0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] // <-- fill with your actual data
  };

  let today = new Date().getDay();
  let currentDay = today;

  function setData(dayIndex) {
    const tbody = document.querySelector("table tbody");
    const heading = document.querySelector(".timetable div h2");
    if (!tbody || !heading) return;

    tbody.innerHTML = "";
    heading.textContent = weekdays[dayIndex];

    const schedule = timetableData[dayIndex];
    schedule.forEach((sub, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${sub.start_time}</td>
        <td>${sub.end_time}</td>
        <td>${sub.subject}</td>
        <td></td>
      `;
      tbody.appendChild(tr);

      if (index === 4) {
        const lunch = document.createElement("tr");
        lunch.innerHTML = `<td></td><td>LUNCH</td><td></td><td></td>`;
        tbody.appendChild(lunch);
      }
    });
  }

  window.timeTableAll = function () {
    document.getElementById("timetable")?.classList.add("active");
    setData(today);
  };

  nextDay?.addEventListener("click", () => {
    currentDay = (currentDay + 1) % 7;
    setData(currentDay);
  });

  prevDay?.addEventListener("click", () => {
    currentDay = (currentDay - 1 + 7) % 7;
    setData(currentDay);
  });

  // Initial display
  document.querySelector(".timetable div h2")!.textContent = "Today's Timetable";

  // — Search function —
  window.myFunction = function () {
    const input = document.getElementById("myInput");
    const filter = input?.value.toUpperCase();
    const table = document.getElementById("myTable");
    const tr = table?.getElementsByTagName("tr");

    if (!input || !filter || !table || !tr) return;

    for (let i = 0; i < tr.length; i++) {
      const td = tr[i].getElementsByTagName("td")[0];
      const txt = td?.textContent || td?.innerText;
      tr[i].style.display = txt?.toUpperCase().includes(filter) ? "" : "none";
    }
  };

  // — Subjective Marks —
  window.handleShowAllSubjectMarks = function (examId) {
    document.getElementById("allResultList")?.classList.add("hide");
    document.querySelector(".marks-table-search-box")?.classList.add("hide");

    fetch("../assets/fetchSubjectiveResults.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "exam_id=" + encodeURIComponent(examId + ""),
    })
      .then(res => res.json())
      .then(data => {
        const table = document.getElementById("subjectiveResultTable");
        if (!table) return;

        table.innerHTML = data.status === "success"
          ? data.data
          : `<h2 style='margin-top:2rem;text-align:center;'>❌ Something went wrong!</h2>`;
      })
      .catch(err => console.error("Error: " + err));
  };

  window.hideSubjectiveListShowFullList = function () {
    document.getElementById("subjectiveResultTable").innerHTML = "";
    document.getElementById("allResultList")?.classList.remove("hide");
    document.querySelector(".marks-table-search-box")?.classList.remove("hide");
  };

  document.querySelectorAll(".no-submit").forEach(el => {
    el.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();
    });
  });
});
});