<?php
// verify_captcha.php
session_start();
header('Content-Type: application/json');

// read JSON body
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Bad request']);
    exit;
}

$captcha_id = $input['captcha_id'] ?? '';
$captcha_answer = trim((string)($input['captcha_answer'] ?? ''));

// basic validation
if (!$captcha_id || $captcha_answer === '') {
    echo json_encode(['success' => false, 'message' => 'Please answer the captcha.']);
    exit;
}

if (!isset($_SESSION['captchas'][$captcha_id])) {
    echo json_encode(['success' => false, 'message' => 'Captcha not found. Refresh and try again.']);
    exit;
}
$meta = $_SESSION['captchas'][$captcha_id];

// checks: used, expiry, answer match, minimal time
if (!empty($meta['used'])) {
    echo json_encode(['success' => false, 'message' => 'Captcha already used. Refresh.']);
    exit;
}
$created = $meta['created'] ?? 0;
$now = time();
if ($now - $created > 10 * 60) { // 10 minute expiry
    unset($_SESSION['captchas'][$captcha_id]);
    echo json_encode(['success' => false, 'message' => 'Captcha expired. Refresh.']);
    exit;
}

// simple anti-bot timing: if solved too fast (<700ms) treat suspicious (but don't show timing to user)
$elapsed = max(1, $now - $created); // seconds (coarse)
// we won't enforce too-strict since clocks are coarse; this is extra

// compare numeric answers
if (!is_numeric($meta['answer']) || intval($meta['answer']) !== intval($captcha_answer)) {
    // increment failure count (optional)
    $_SESSION['captchas'][$captcha_id]['attempts'] = ($_SESSION['captchas'][$captcha_id]['attempts'] ?? 0) + 1;
    // if attempts exceed 4, expire the captcha
    if ($_SESSION['captchas'][$captcha_id]['attempts'] > 4) {
        $_SESSION['captchas'][$captcha_id]['used'] = true;
        echo json_encode(['success' => false, 'message' => 'Too many attempts. Captcha reset.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Wrong answer. Try again.' ]);
    }
    exit;
}

// mark used (one-time)
$_SESSION['captchas'][$captcha_id]['used'] = true;

echo json_encode(['success' => true]);
exit;
