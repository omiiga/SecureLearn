<?php include("../assets/noSessionRedirect.php"); ?>

<?php include("./verifyRoleRedirect.php"); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="icon" type="image/png" href="../images/2.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/oranbyte-google-translator.css">

    <style type="text/css">
	 /* -------------------------
     GLOBAL STYLES
     ------------------------- */
	 	:root {
    --header-height: 56px;
    --padding-h: 16px;
  }

  
  body {
    margin: 0;
    padding: 0;
    background-color: #fafafa;
    color: #222;
    font-family: sans-serif;
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  /* Dark mode for search input and table */
body.dark-mode #myInput {
    background-color: #2b2b2b; /* dark background */
    color: #f0f0f0;            /* readable text */
    border: 1px solid #555;    /* darker border for contrast */
    background-image: url('search.svg'); /* keep search icon */
    background-position: 5px 2px;
    background-repeat: no-repeat;
}

body.dark-mode #myTable {
    background-color: #2b2b2b; /* dark background */
    color: #f0f0f0;            /* readable text */
    border: 1px solid #555;    /* border visible in dark mode */
}

body.dark-mode #myTable th {
    background-color: #3a3a3a; /* slightly lighter than table body */
    color: #f0f0f0;
}

body.dark-mode #myTable tr.header,
body.dark-mode #myTable tr:hover {
    background-color: #444;    /* highlight row in dark mode */
}

body.dark-mode #myTable th,
body.dark-mode #myTable td {
    text-align: center;
    padding: 12px;
    border-radius: 16px;
}

/* Optional: make link buttons compatible with dark mode */
body.dark-mode .link-btn {
    background-color: rgb(150 130 200 / 50%);
    color: #f0f0f0;
    border: 1px solid rgb(180 150 255);
}


  /* -------------------------
     MODULE‐WRAPPER STYLES
     ------------------------- */
  .module-wrapper {
    margin: auto;
    max-width: 800px;
    padding: 20px;
    background-color: #e0e0e0;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  .module-wrapper h2.module-title {
    text-align: center;
    color: #333;
  }

  .folder {
    margin-bottom: 10px;
  }

  .folder-name {
    font-weight: bold;
    cursor: pointer;
    padding: 10px;
    background: #ccc;
    border-radius: 5px;
    color: #333;
    transition: background-color 0.3s ease, color 0.3s ease;
  }

  .file-list {
    display: none;
    margin-left: 20px;
    margin-top: 5px;
    color: #333;
  }

  .file-list li {
    margin: 8px 0;
    list-style: none;
  }

  .launch-btn {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.95rem;
    transition: background-color 0.3s ease;
  }

  .popup-frame {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 80%;
    height: 80%;
    border: none;
    z-index: 1000;
    display: none;
    box-shadow: 0 0 10px rgba(0,0,0,0.5);
  }

  #popup-bg {
    display: none;
    position: fixed;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 999;
  }

  /* Toggle Switch (Admin style) */
.toggle-switch {
  position: relative;
  width: 50px;
  height: 24px;
  display: inline-block;
  margin-left: 15px;
}

.toggle-switch input {
  display: none;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 34px;
}

.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .slider {
  background-color: #2196F3; /* Blue like Admin */
}

input:checked + .slider:before {
  transform: translateX(26px);
}

.header-right {
  display: flex;
  align-items: center;
  gap: 15px;
  position: absolute;
  right: 20px;
  top: 15px;
}


  /* -------------------------
     GLOBAL DARK MODE
     ------------------------- */
  body.dark-mode {
    background-color: #121212;
    color: #e0e0e0;
  }

  body.dark-mode header,
  body.dark-mode footer {
    background-color: #1e1e1e;
    color: #e0e0e0;
  }

  /* Default (light mode) */
/* .eg acts as the "white board" — it will flip in dark mode */
.eg {
  background: #ffffff;
  color: #000000;
  padding: 18px;
  border-radius: 10px;
  transition: background-color .25s ease, color .25s ease;
}

/* When dark mode is active (body has class "dark-mode") */
body.dark-mode .eg {
  background: #1e1e1e;  /* same dark background as admin */
  color: #ffffff;
}

/* Light mode - updates board flat, messages no shadow */
.announcements .updates {
    background-color: #f9f9f9;
    border-radius: 10px;
    box-shadow: none; /* flat board */
    padding: 10px;
    transition: background-color 0.3s ease;
}

.announcements .message {
    background-color: inherit; /* same as board */
    color: #000000;            /* readable text */
    box-shadow: none;           /* remove shadow in light mode */
    transition: background-color 0.3s ease, color 0.3s ease, box-shadow 0.3s ease;
}

.announcements .message:hover {
    box-shadow: none; /* no shadow on hover */
}

/* Dark mode */
body.dark-mode .announcements .updates {
    background-color: #2b2b2b;
}

body.dark-mode .announcements .message {
    color: #f0f0f0;
    box-shadow: none; /* remains no shadow */
}

/* Teacher feedback board - light mode */
.teacher {
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1); /* initial shadow */
    padding: 15px;
    transition: box-shadow 0.3s ease, background-color 0.3s ease, color 0.3s ease;
}

.teacher:hover {
    box-shadow: none; /* shadow fades on hover */
}

/* Dark mode */
body.dark-mode .teacher {
    background-color: #2b2b2b;   /* dark background */
    color: #f0f0f0;              /* readable text */
    box-shadow: 0 4px 6px rgba(255,255,255,0.05); /* visible shadow in dark mode */
}

body.dark-mode .teacher:hover {
    box-shadow: none; /* fade shadow on hover */
}




  /* -------------------------
     MODULE WRAPPER DARK MODE
     ------------------------- */
  body.dark-mode .module-wrapper {
    background-color: #2f3d4a;
    color: #e0e0e0;
  }

  body.dark-mode .module-wrapper h2.module-title {
    color: #f0f0f0;
  }

  body.dark-mode .module-wrapper .folder-name {
    background: #25303a;
    color: #d4d4d4;
  }

  body.dark-mode .module-wrapper .file-list {
    color: #cccccc;
  }

  body.dark-mode .module-wrapper .launch-btn {
    background-color: #1a73e8;
  }
        .container main .subjects .eg #piechart {
            width: 600px;
            height: 350px;
            padding-right: 0%;
            position: relative;
            border-radius: 20px;
        }

        .container main .subjects .eg {
            border-radius: 20px;
        }

        @media screen and (max-width: 700px) {
            .container main .subjects .eg #piechart {
                width: 250px;
                height: 200px;
                padding-left: 0%;
                padding-right: 0%;

            }

            .container main .subjects {
                margin-left: 4%;
            }

            .leaves {
                width: 106%;
                /*margin-left: 5%;*/
                font-size: 10px;
                padding-right: 0;
            }

        }

        #myInput {
            background-image: url('search.svg');
            /* Add a search icon to input */
            background-position: 5px 2px;
            /* Position the search icon */
            background-repeat: no-repeat;
            /* Do not repeat the icon image */
            width: 80%;
            /* Full-width */
            font-size: 16px;
            /* Increase font-size */
            padding: 12px 20px 12px 40px;
            /* Add some padding */
            border: 1px solid #ddd;
            /* Add a grey border */
            margin-bottom: 12px;
            /* Add some space below the input */
            border-radius: 40px;
            position: relative;
        }

        #myTable {
            width: 80%;
            /* Full-width */
            border: 1px solid #ddd;
            /* Add a grey border */
            font-size: 15px;
            /* Increase font-size */
            border-radius: 40px;
            position: relative;
        }

        #myTable th {
            background-color: #A9A9A9;
            color: white;
        }

        #myTable th,
        #myTable td {
            text-align: center;
            /* Left-align text */
            padding: 12px;
            /* Add padding */
            border-radius: 16px;
        }


        #myTable tr {
            /* Add a bottom border to all table rows */
            border-bottom: 1px solid #ddd;
            border-radius: 40px;
            text-align: center;
        }

        #myTable tr.header,
        #myTable tr:hover {
            /* Add a grey background color to the table header and on hover */
            background-color: #f1f1f1;
        }

        @media only screen and (max-width: 768px) {
            #myTable {
                width: 95%;
                margin: 0%;
                font-size: 12.5px;
            }

            #myInput {
                width: 95%;
                margin: 0%;
            }
        }

        .link-btn {
            display: block;
            border: 1px solid rgb(214 183 255);
            background-color: rgb(212 196 255 / 77%);
            color: #000000;
            padding: 8px 10px;
            border-radius: 5px;
            max-width: 100px;
            text-align: center;
        }
    </style>
</head>

<body>
         <header>
        <div class="logo" title="SecureLearn">
            <img src="./images/2.png" alt="">
            <h2>Secure<span class="danger">Learn</span></h2>
        </div>
      <div style="
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    gap: 1rem;
    overflow-x: auto;
    white-space: nowrap;
">
    <div class="navbar" style="
        display: inline-flex;
        gap: 1rem;
    ">

        <a href="" class="" onclick="" style="">
            <span class=""></span>
            <h3 style=""></h3>
        </a>
		        <a href="" class="" onclick="" style="">
            <span class=""></span>
            <h3 style=""></h3>
        </a>

		<a href="timetable.php" onclick="timeTableAll()" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">today</span>
            <h3 style="margin: 0; font-size: 1rem;">Time Table</h3>
        </a>
        <a href="exam.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">grid_view</span>
            <h3 style="margin: 0; font-size: 1rem;">Examination</h3>
        </a>
        <a href="workspace.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Syllabus</h3>
        </a>
        <a href="modules.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">description</span>
            <h3 style="margin: 0; font-size: 1rem;">Modules</h3>
        </a>
        <a href="password.php" style="text-decoration: none; text-align: center;">
            <span class="material-icons-sharp">password</span>
            <h3 style="margin: 0; font-size: 1rem;">Change Password</h3>
        </a>

    </div>

 


</div>
   <div class="header-right">
  <label class="toggle-switch">
    <input type="checkbox" id="themeToggle">
    <span class="slider"></span>
  </label>

  <a href="logout.php">Logout</a>
</div>

        
    </header>
    <div class="container">
        <aside>
            <div class="profile">
                <div class="top">
                   <?php
                   echo '<div class="profile-photo">
                   <img src="./images/profile.png" alt="Profile Photo">
                    </div>';
                    ?>


                    <div class="info">
                        <?php
                        session_start();
                        $id = $_SESSION['uid'];
                        $query = "select * from students where id='$id'";
                        $result = $conn->query($query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "
                            <p>Hey, <b>" . $row["fname"] . "</b> </p>
                        <small class='text-muted'><b>ID&nbsp;:&nbsp;</b>" . $row["id"] . "</small>";
                            }
                        }
                        ?>

                    </div>
                </div>
                <br>
               
                <div class="about">
                    <?php
                    $query = "select * from students where id='$id'";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<p><h5>Class : " . $row["class"] . "</h5></p>
                    <p>Section " . $row["section"] . "</p>
                    <h5>DOB</h5>
                    <p>" . $row["dob"] . "</p>
                    <h5>Contact</h5>
                    <p>" . $row["phone"] . "</p>
                    <h5>Email</h5>
                    <p>" . $row["email"] . "</p>
                    <h5>Address</h5>
                    <p>" . $row["address"] . "</p>";
                        }
                    }

                    ?><br>

                    <div style="display: inline;">
                  

                    
                    </div>
                </div>
            </div>
        </aside>

        <main>
    <h1>Attendance</h1>
    <div class="subjects">
        <div class="eg">
            <!-- Custom Title above the chart -->
            <h2 style="text-align:center; margin-bottom: -5px;">
                Student Attendance All time
            </h2>
            
            <!-- Chart itself -->
            <div id="piechart" style="width: 600px; height: 400px; margin: 0 auto;"></div>
        </div>
    </div>



            <div class="leaves " style="margin-top: 20px;">
                <h2>Syllabus</h2>
                <?php
                $id = $_SESSION['uid'];
                $query_sql = "SELECT * FROM students WHERE id='$id'";
                $result = mysqli_query($conn, $query_sql);
                $row = $result->fetch_assoc();
                $class = $row['class'];

                $sql2 = "SELECT * FROM syllabus WHERE class='$class'";
                $result2 = mysqli_query($conn, $sql2);
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        echo "<div class='teacher'>
                    <div class='profile-photo'>
                    <a href='../syllabusUploads/" . $row2['file'] . "'>
                    <img src='./images/profile-2.png' alt=''></div>
                    <div class='info'>
                        <h3>" . $row2['subject'] . "</h3>
                        <small class='text-muted'>Download or View</small>
                        </a>
                    </div>
                </div>";
                    }
                } else {
                    echo '<p style="padding-left: 20px;margin-top: 10px;">Syllabus not uploaded yet!</p>';
                }
                ?>


            </div>
            <div class="timetable" id="timetable">
                <h2>Monthly Attendance</h2>
                <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Date...">

                <table id="myTable">
                    <tr class="header">
                        <th style="width:60%;">Date</th>
                        <th style="width:40%;">Attendence</th>
                    </tr>
                    <tbody id="attendence_table">

                    </tbody>
                </table>
                <br><br>
            </div>
        </main>

        <div class="right">
            <div class="announcements">
                <h2>Notice Board</h2>
                <div class="updates">
                    <div class="message">
                        <?php
                        $id = $_SESSION['uid'];
                        $query_sql2 = "SELECT * FROM students WHERE id='$id'";
                        $result = mysqli_query($conn, $query_sql2);
                        $row = $result->fetch_assoc();
                        $class = $row['class'];

                        $sql_query = "SELECT * FROM notice WHERE (role = 'student' AND class='$class') OR (role = 'all' OR role='') ORDER BY s_no DESC LIMIT 3";
                        $result = mysqli_query($conn, $sql_query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<p> <b>" . $row['title'] . "</b> <br>" . $row['body'] . "<br></p>";
                                if ($row['file'] != null) {
                                    echo "<a href='../noticeUploads/" . $row['file'] . "'><img src='file.svg' height='30px' width='30px'><p style='color:red;'>View Notice</p></a>";
                                }
                                echo "<small class='text-muted'><b>" . $row['timestamp'] . "</b></small><hr><br>";
                            }
                        }
                        ?>



                    </div>

                </div>
            </div>

            <div class="leaves">
                <h2>Feedbacks</h2>
                <?php
                $id = $_SESSION['uid'];

                $sql2 = "SELECT * FROM `feedback` WHERE `receiver_id`='$id' LIMIT 5";
                $result2 = mysqli_query($conn, $sql2);
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        $timestamp = $row2['timestamp'];
                        $formattedDate = date('d M, Y', strtotime($timestamp));

                        $senderId = $row2['sender_id'];
                        $tableName = ($senderId >= 1000) ? 'admins' : 'teachers';
                        $sql = "SELECT `fname`, `lname` FROM `$tableName` WHERE id = '$senderId' LIMIT 1";

                        $result = mysqli_query($conn, $sql);
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $sender = ucfirst(strtolower($row['fname'])) . " " . strtolower($row['lname']);
                        } else {
                            $sender = "REMOVED";
                        }

                        echo "<div class='teacher'>
                            <div class='info' style='width: 100%;'>
                                <p class='text-muted para-text'>
                                <i class='bx bxs-chat' ></i>
                                " . $row2['msg'] . "</p>
                                <div class='flexbox' style='margin-top: 8px;'>
                                    <small>" . $formattedDate . "</small>
                                    <small style='margin-left: auto;'>" .  $sender . "</small>
                                </div>
                            </div>
                        </div>";
                    }
                } else {
                    echo "<div class='teacher'>
                    <div class='info' style='width: 100%;'>
                        <p class='text-muted para-text'>
                        <i class='bx bxs-chat' ></i>
                       No Feedbacks</p>
                       
                    </div>
                </div>";
                }
                ?>


            </div>

        </div>
    </div>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        let presentPer = 30;
        let absentPer = 70;


        document.addEventListener("DOMContentLoaded", function() {
            fetch("fetchAttendencePercentage.php", {
                    method: "POST",
                })
                .then(response => response.json())
                .then(data => {


                    if (data['status'] === "success") {
                        presentPer = parseFloat(data['present']);
                        absentPer = parseFloat(data['absent']);



                        google.charts.load("current", {
                            packages: ["corechart"]
                        });
                        google.charts.setOnLoadCallback(drawChart);

                    } else {
                        alert("Something went wrong!");
                    }
                })
                .catch(error => {
                    console.error("error" + error)
                })
        });


        function drawChart() {
    var data = google.visualization.arrayToDataTable([
        ['Attendance', 'Percentage'],
        ['Present', presentPer],
        ['Absent', absentPer],
    ]);

    // Detect if dark mode is active
    var darkMode = document.body.classList.contains('dark-mode');

    var options = {
        legend: 'none',
        pieSliceText: 'label',
        pieStartAngle: 100,
        chartArea: {
            left: 20,
            top: 30,
            width: '90%',
            height: '75%',
            backgroundColor: { fill: 'transparent' }
        },
        backgroundColor: { fill: 'transparent' },
        pieSliceBorderColor: darkMode ? '#222' : '#fff', // 👈 outline color
        titleTextStyle: {
            color: darkMode ? '#fff' : '#333',
            fontSize: 18,
            bold: true
        }
    };

    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
    chart.draw(data, options);
}
		
    </script>


    <script type="text/javascript" src="app.js"></script>
    <!-- <script type="text/javascript" src="timeTable.js"></script> -->
    <script type="text/javascript" src="index.js"></script>
    <script src="../js/oranbyte-google-translator.js"></script>

    <script>
  const toggle = document.getElementById('themeToggle');
  toggle.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode', toggle.checked);
    localStorage.setItem('theme', toggle.checked ? 'dark' : 'light');
  });

  // Load saved preference
  window.onload = () => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark') {
      toggle.checked = true;
      document.body.classList.add('dark-mode');
    }
  }
</script>

</body>

</html>