<footer>
  <div class="container">
    <div class="row d-flex align-items-center">
      <div class="col-md-4 text-center text-md-start">
        <img src="images/1.png" alt="Website Logo" class="img-fluid" />
        <p>SecureLearn</p>
        <p>BSIT-CYB42 UNIVERSIDAD DE MANILA</p>
      </div>
      <div class="col-md-4 text-center">
        </div>
      <div class="col-md-4 text-center text-md-end">
        <p>
          Time Zone:
          <?php
          date_default_timezone_set('Asia/Manila');
          $current_time = date('D M d Y H:i:s \G\M\TO (T)');
          echo "<p>$current_time</p>";
          ?>
        </p>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-12 text-center">
        <p>
          &copy; <?php echo date('Y'); ?> Inspired by:
          <a href="https://www.github.com/ProjectsAndPrograms" target="_blank">
            ProjectsAndPrograms
          </a>
          . All rights reserved.
        </p>
      </div>
    </div>
  </div>
</footer>



  <script src="https://kit.fontawesome.com/a81368914c.js"></script>
  <script src="js/bootstrap.bundle.js"></script>
  <script src="./shared/app.js"></script>
</body>

</html>
