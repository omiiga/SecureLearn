<header>
  <div class="container">
    <div class="logo">
      <a href="./index.php">
        <img src="./images/2.png" alt="Logo" />
      </a>
      <a href="./index.php">
        <h3>SecureLearn</h3>
      </a>
    </div>

    <div class="nav-container">

      <div class="links">
        <ul>
          <li><a href="./about-us.php">About-us</a></li>
          <li>
  <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginRoleModal">
    Login
  </a>
</li>
        </ul>


      </div>
      <div class="bottom-area">
        <div class="container">
          <button class="toggle-btn">
            <i class="far fa-moon"></i>
            <i class="far fa-sun"></i>
          </button>
        </div>
      </div>
    </div>
    <div class="overlay"></div>

    <div class="hamburger-menu">
      <div class="bar"></div>
    </div>
  </div>
</header>