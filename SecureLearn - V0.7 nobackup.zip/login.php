<?php
session_start();
require_once "assets/config.php";

$max_attempts = 5;
$lockout_time = 300; // 5 minutes

// Server-side captcha verification helper (supports preverified -> consume)
function server_verify_captcha($captcha_id, $captcha_answer) {
    if (!$captcha_id) return ['ok' => false, 'msg' => 'Captcha required'];

    if (!isset($_SESSION['captchas'][$captcha_id])) {
        return ['ok' => false, 'msg' => 'Captcha not found. Refresh and try again.'];
    }
    $meta = &$_SESSION['captchas'][$captcha_id];

    if (!empty($meta['used'])) {
        return ['ok' => false, 'msg' => 'Captcha already used. Refresh.'];
    }

    if (time() - ($meta['created'] ?? 0) > 10 * 60) {
        unset($_SESSION['captchas'][$captcha_id]);
        return ['ok' => false, 'msg' => 'Captcha expired. Refresh.'];
    }

    if (!empty($meta['preverified'])) {
        $meta['used'] = true;
        unset($meta['preverified']);
        return ['ok' => true];
    }

    if ($captcha_answer === '') {
        return ['ok' => false, 'msg' => 'Captcha required'];
    }

    if (!is_numeric($meta['answer']) || intval($meta['answer']) !== intval($captcha_answer)) {
        $meta['attempts'] = ($meta['attempts'] ?? 0) + 1;
        if ($meta['attempts'] > 4) {
            $meta['used'] = true;
            return ['ok' => false, 'msg' => 'Too many attempts. Captcha reset.'];
        }
        return ['ok' => false, 'msg' => 'Wrong answer. Try again.'];
    }

    $meta['used'] = true;
    return ['ok' => true];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = trim($_POST['role'] ?? '');
    $email = trim($_POST['Email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $captcha_id = $_POST['captcha_id'] ?? '';
    $captcha_answer = trim((string)($_POST['captcha_answer'] ?? ''));
    $honeypot = trim($_POST['hp_name'] ?? '');

    // Generic helper to set session-driven error and redirect to index
$fail_and_redirect = function($message, $attempt_key = null, $attempt_data = null) {
    $_SESSION['login_error'] = 'Login failed. Please try again.';
    if ($attempt_data !== null && isset($attempt_data['locked_until'])) {
        $_SESSION['locked_until'] = intval($attempt_data['locked_until']);
    } else {
        if (!isset($_SESSION['locked_until'])) $_SESSION['locked_until'] = 0;
    }

    // flush session immediately to avoid races with redirect
    session_write_close();

    // make redirect relative if your site is not at webroot
    header('Location: /index.php');
    exit;
};

    if (empty($role) || empty($email) || empty($password)) {
        $fail_and_redirect('Email, Password and Role are required.');
    }

    // honeypot check
    if (!empty($honeypot)) {
        $fail_and_redirect('Invalid submission.');
    }

    // verify captcha (this will consume when appropriate)
    $cv = server_verify_captcha($captcha_id, $captcha_answer);
    if (!$cv['ok']) {
        // Do not echo $cv['msg'] to user; keep it generic.
        $fail_and_redirect('Captcha failed.');
    }

    if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = [];
    $attempt_key = $role . ':' . $email;
    $attempt_data = $_SESSION['login_attempts'][$attempt_key] ?? ['count'=>0,'locked_until'=>0];
    $now = time();

    // If user currently locked, set session lock info and redirect
    if (!empty($attempt_data['locked_until']) && $attempt_data['locked_until'] > $now) {
        $_SESSION['login_error'] = 'Too many failed attempts. Please wait before retrying.';
        $_SESSION['locked_until'] = intval($attempt_data['locked_until']);
        header('Location: /index.php');
        exit;
    }

    // Fetch user
    $stmt = mysqli_prepare($conn, "SELECT id, password_hash, role FROM users WHERE email=?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    mysqli_stmt_bind_result($stmt, $uid, $password_hash, $db_role);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    $auth_ok = false;
    if ($uid && password_verify($password, $password_hash)) {
        if ($role === $db_role) {
            $auth_ok = true;
        } else {
            // role mismatch — treat as auth failure (do NOT expose role mismatch)
            $auth_ok = false;
        }
    }

    if ($auth_ok) {
        // success -> clear counters for this attempt_key
        unset($_SESSION['login_attempts'][$attempt_key]);
        // clear any top-level session indicators so index won't re-show messages
        unset($_SESSION['login_error'], $_SESSION['locked_until']);
        $_SESSION['uid'] = $uid;
        if ($role === 'student') header("Location: /student_panel/index.php");
        elseif ($role === 'teacher') header("Location: /teacher_panel/dashboard.php");
        elseif ($role === 'admin') header("Location: /admin_panel/dashboard.php");
        else header("Location: /index.php");
        exit;
    } else {
        // failed auth -> increment counter
        $attempt_data['count'] = ($attempt_data['count'] ?? 0) + 1;
    }

    // Lock logic
    if ($attempt_data['count'] >= $max_attempts) {
        $attempt_data['locked_until'] = $now + $lockout_time;
        $attempt_data['count'] = 0; // reset count after lock
    }

// persist per-key attempt info
$_SESSION['login_attempts'][$attempt_key] = $attempt_data;

// also expose a small, explicit info blob so front-end doesn't need to inspect arrays
$_SESSION['login_attempt_info'] = [
    'attempt_key' => $attempt_key,
    'count'       => intval($attempt_data['count'] ?? 0),
    'locked_until'=> intval($attempt_data['locked_until'] ?? 0)
];

// top-level generic UI indicators (no leaks)
$_SESSION['login_error'] = 'Login failed. Please try again.';
$_SESSION['locked_until'] = intval($attempt_data['locked_until'] ?? 0);
$_SESSION['login_role'] = $role; // keep but DO NOT show on UI

// Make sure session is written immediately so index.php can read it after redirect
session_write_close();

// Redirect back to index (no query string)
header('Location: /index.php');
exit;
}
?>
