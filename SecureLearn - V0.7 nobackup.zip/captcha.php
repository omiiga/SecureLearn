<?php
// captcha.php
session_start();
header('Content-Type: application/json');

// simple server-side captcha creation (same logic as index.php create_captcha)
function create_captcha_json() {
    $a = rand(1, 9);
    $b = rand(1, 9);
    $ops = ['+','*'];
    $op = $ops[array_rand($ops)];
    $answer = ($op === '+') ? ($a + $b) : ($a * $b);
    $id = bin2hex(random_bytes(8));
    // store answer + meta in session
    if (!isset($_SESSION['captchas']) || !is_array($_SESSION['captchas'])) $_SESSION['captchas'] = [];
    $_SESSION['captchas'][$id] = [
        'answer' => $answer,
        'created' => time(),
        'used' => false
    ];
    return ['id' => $id, 'question' => "{$a} {$op} {$b} = ?"];
}

$target = isset($_GET['target']) ? $_GET['target'] : 'login';
$cap = create_captcha_json();
echo json_encode($cap);