<?php
// index_fixed_with_lockout_and_modal_colors.php
// Drop-in replacement of your index_fixed.php with session-driven server lock info
// and modal coloring. Keeps the AJAX captcha preverify flow intact.

session_start();



/**
 * Endpoints:
 *  - GET  index.php?action=captcha&target=login|forgot  -> JSON { id, question }
 *  - POST index.php?action=verify                       -> JSON { success, message }
 */

// Utility: create captcha and store in session
function create_captcha() {
    $a = rand(1, 9);
    $b = rand(1, 9);
    $ops = ['+','*'];
    $op = $ops[array_rand($ops)];
    $answer = ($op === '+') ? ($a + $b) : ($a * $b);
    $id = bin2hex(random_bytes(8));
    if (!isset($_SESSION['captchas']) || !is_array($_SESSION['captchas'])) $_SESSION['captchas'] = [];
    $_SESSION['captchas'][$id] = [
        'answer' => $answer,
        'created' => time(),
        'used' => false,
        'attempts' => 0
    ];
    return ['id' => $id, 'question' => "{$a} {$op} {$b} = ?"];
}

// AJAX endpoints
if (isset($_GET['action']) && $_GET['action'] === 'captcha') {
    header('Content-Type: application/json; charset=utf-8');
    $cap = create_captcha();
    echo json_encode($cap);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'verify') {
    header('Content-Type: application/json; charset=utf-8');
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'Bad request']);
        exit;
    }
    $captcha_id = $input['captcha_id'] ?? '';
    $captcha_answer = trim((string)($input['captcha_answer'] ?? ''));

    if (!$captcha_id || $captcha_answer === '') {
        echo json_encode(['success' => false, 'message' => 'Please answer the captcha.']);
        exit;
    }

    if (!isset($_SESSION['captchas'][$captcha_id])) {
        echo json_encode(['success' => false, 'message' => 'Captcha not found. Refresh and try again.']);
        exit;
    }
    $meta = &$_SESSION['captchas'][$captcha_id];

    if (!empty($meta['used'])) {
        echo json_encode(['success' => false, 'message' => 'Captcha already used. Refresh.']);
        exit;
    }

    if (time() - ($meta['created'] ?? 0) > 10 * 60) { // 10 minutes expiry
        unset($_SESSION['captchas'][$captcha_id]);
        echo json_encode(['success' => false, 'message' => 'Captcha expired. Refresh.']);
        exit;
    }

    if (!is_numeric($meta['answer']) || intval($meta['answer']) !== intval($captcha_answer)) {
        $meta['attempts'] = ($meta['attempts'] ?? 0) + 1;
        if ($meta['attempts'] > 4) {
            $meta['used'] = true;
            echo json_encode(['success' => false, 'message' => 'Too many attempts. Captcha reset.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Wrong answer. Try again.']);
        }
        exit;
    }

    // correct: mark as pre-verified so final submit can consume it
    $meta['preverified'] = true;
    echo json_encode(['success' => true]);
    exit;
}

// Normal page load: create initial captchas (fast render fallback)
$login_captcha = create_captcha();
$forgot_captcha = create_captcha();

// Read server-side lock info (login.php or authentication backend should set these session keys)
$server_lock_info = [
    'attempts' => isset($_SESSION['login_attempts']) ? intval($_SESSION['login_attempts']) : 0,
    'locked_until' => isset($_SESSION['locked_until']) ? intval($_SESSION['locked_until']) : 0,
    'login_error' => isset($_SESSION['login_error']) ? $_SESSION['login_error'] : '',
    'role' => isset($_SESSION['login_role']) ? $_SESSION['login_role'] : ''
];
// clear them so subsequent loads won't re-trigger unless backend sets again
unset($_SESSION['login_attempts'], $_SESSION['locked_until'], $_SESSION['login_error'], $_SESSION['login_role']);

include('shared/_header.php');
?>

<main>
  <div class="big-wrapper light">
    <img src="./images/shape.png" alt="" class="shape" />

    <?php include('shared/_navbar.php'); ?>

    <!-- Hero Section -->
    <div class="container my-5">
      <div class="row g-4 align-items-center">
        <!-- Text Block -->
        <div class="col-12 col-md-6 d-flex justify-content-center">
          <div class="text-center text-md-start">
            <div class="big-title mb-3">
              <h1 class="fw-bold display-5">Safeguard the future.</h1>
              <h1 class="fw-bold display-5">Learn to secure it.</h1>
            </div>
            <p class="text-muted lead mb-4">
              Learn how to do ethical hacking and how to prevent attacks, and enhance Cybersecurity awareness effectively!
            </p>
            <div class="cta">
              <!-- Trigger Role Selection Modal -->
              <button class="btn btn-primary btn-lg px-4" data-bs-toggle="modal" data-bs-target="#loginRoleModal">
                Get started
              </button>
            </div>
          </div>
        </div>

        <!-- Image Block -->
<div class="col-12 col-md-6">
  <img
    src="./images/kids.png"
  />
</div>
      </div>
    </div>

    <!-- Feature Cards -->
    <?php include('shared/feature-cards.php'); ?>

    <!-- Divider -->
    <div class="container my-4">
      <hr>
    </div>

    <!-- Carousel -->
    <div class="container my-4 carousel-box">
      <div id="carouselExample" class="carousel slide">
        <div class="carousel-inner rounded shadow-sm">
          <div class="carousel-item active">
            <img src="images/learning.png" class="d-block w-100" alt="Slide 1">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
</main>

<!-- Role selection modal -->
<div class="modal fade modal-theme role-modal" id="loginRoleModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow-lg rounded-4">
      <div class="modal-header border-0" id="loginRoleModalHeader">
        <h5 class="modal-title fw-bold w-100 text-center">Are you a.....?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="loginRoleModalBody">
        <div class="row g-3 text-center">
          <div class="col-4">
            <div class="role-card role-student d-flex flex-column justify-content-center align-items-center" data-role="student">
              <img src="images/student.png" alt="Student" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
              <h6 class="fw-bold">Student</h6>
            </div>
          </div>
          <div class="col-4">
            <div class="role-card role-teacher d-flex flex-column justify-content-center align-items-center" data-role="teacher">
              <img src="images/teacher.png" alt="Teacher" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
              <h6 class="fw-bold">Teacher</h6>
            </div>
          </div>
          <div class="col-4">
            <div class="role-card role-admin d-flex flex-column justify-content-center align-items-center" data-role="admin">
              <img src="images/admin.png" alt="Admin" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
              <h6 class="fw-bold">Admin</h6>
            </div>
          </div>
        </div>
        <div class="text-center mt-3">
          <a href="#" class="text-decoration-underline text-muted small" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
            Lost / Forgot password?
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
  const toggleBtn = document.querySelector(".bottom-area .toggle-btn");
  const wrapper = document.querySelector(".big-wrapper");
  if (!toggleBtn || !wrapper) return;

  const moonIcon = toggleBtn.querySelector(".fa-moon");
  const sunIcon = toggleBtn.querySelector(".fa-sun");

  function applyTheme(isDark) {
    if (isDark) {
      wrapper.classList.add("dark");
      wrapper.classList.remove("light");
      moonIcon.style.display = "none";
      sunIcon.style.display = "inline-block";
      toggleBtn.setAttribute("aria-pressed", "true");
    } else {
      wrapper.classList.add("light");
      wrapper.classList.remove("dark");
      sunIcon.style.display = "none";
      moonIcon.style.display = "inline-block";
      toggleBtn.setAttribute("aria-pressed", "false");
    }

    // sync modals every time
    document.querySelectorAll(".modal-theme").forEach(m => {
      if (isDark) {
        m.classList.add("dark");
        m.classList.remove("light");
      } else {
        m.classList.add("light");
        m.classList.remove("dark");
      }
    });
  }

  // Ensure wrapper starts with a theme
  if (!wrapper.classList.contains("light") && !wrapper.classList.contains("dark")) {
    wrapper.classList.add("light");
  }

  // Apply initial theme based on wrapper
  applyTheme(wrapper.classList.contains("dark"));

  // Toggle on button click
  toggleBtn.addEventListener("click", function () {
    const isCurrentlyDark = wrapper.classList.contains("dark");
    applyTheme(!isCurrentlyDark);
  });

  // Ensure modals always match theme when shown
  document.addEventListener("show.bs.modal", function (e) {
    const m = e.target;
    if (m.classList.contains("modal-theme")) {
      applyTheme(wrapper.classList.contains("dark"));
    }
  });
});
</script>
<hr>

<!-- Login modal (colored header) -->
<div class="modal fade modal-theme login-modal light" id="loginModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow-lg rounded-4 p-4">
      <div class="modal-header border-0">
        <h5 class="modal-title fw-bold">Login as <span id="selectedRoleLabel">User</span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="roleLoginForm" method="POST" action="login.php" novalidate>
          <input type="hidden" name="role" id="roleField" value="">
          <input type="text" name="hp_name" id="hp_name" style="display:none" autocomplete="off">

          <div class="mb-3">
            <label for="loginUsername" class="form-label">Email</label>
            <input type="email" name="Email" id="loginUsername" class="form-control shadow-sm" placeholder="Enter your email" required autocomplete="off">
          </div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!-- Replace your password block with this -->
<div class="mb-3 position-relative">
  <label for="loginPassword" class="form-label">Password</label>
  <div class="input-group">
    <input type="password" name="password" id="loginPassword" class="form-control shadow-sm" placeholder="Enter your password" required autocomplete="new-password">
    <button class="btn btn-eye" type="button" id="togglePasswordVisibility" aria-pressed="false" aria-label="Show password">
      <i class="bi bi-eye-slash" id="togglePasswordIcon" aria-hidden="true"></i>
    </button>
  </div>
</div>




          <div class="mb-3">
            <label class="form-label">Prove you're human</label>
            <div class="d-flex gap-2 align-items-center">
              <div id="loginCaptchaQuestion" class="captcha-question"><?= htmlspecialchars($login_captcha['question']) ?></div>
              <button type="button" id="loginCaptchaRefresh" class="btn btn-sm btn-outline-secondary captcha-refresh" aria-label="Refresh captcha">↻</button>
            </div>
            <input type="hidden" name="captcha_id" id="loginCaptchaId" value="<?= htmlspecialchars($login_captcha['id']) ?>">
            <input type="text" name="captcha_answer" id="loginCaptchaAnswer" class="form-control mt-2" placeholder="Answer" required autocomplete="off">
            <div id="loginCaptchaError" class="form-text text-danger" style="display:none;"></div>
          </div>

          <div id="serverStatus" class="mb-3" style="display:none;"></div>

          <button id="loginSubmitBtn" type="submit" class="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Forgot modal (distinct color) -->
<div class="modal fade modal-theme forgot-modal light" id="forgotPasswordModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow-lg rounded-4 p-4">
      <div class="modal-header border-0" style="background:#fff9ec;color:#7a5a00;">
        <h5 class="modal-title fw-bold">Forgot Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-3">Enter your email and select your role to receive a password reset link:</p>
        <form id="forgotPasswordForm" method="POST" action="ForgotPassword_BE.php">
          <input type="hidden" name="role" id="forgotRoleField" value="">
          <div class="mb-3">
            <label for="forgotEmail" class="form-label">Email</label>
            <input type="email" name="email" id="forgotEmail" class="form-control shadow-sm" placeholder="Enter your email" required autocomplete="off">
          </div>
          <div class="mb-3">
            <label class="form-label">Role</label>
            <div class="row g-3 text-center mb-3">
              <div class="col-4">
                <div class="role-card role-student d-flex flex-column justify-content-center align-items-center" data-role="student">
                  <img src="images/student.png" alt="Student" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                  <h6 class="fw-bold">Student</h6>
                </div>
              </div>
              <div class="col-4">
                <div class="role-card role-teacher d-flex flex-column justify-content-center align-items-center" data-role="teacher">
                  <img src="images/teacher.png" alt="Teacher" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                  <h6 class="fw-bold">Teacher</h6>
                </div>
              </div>
              <div class="col-4">
                <div class="role-card role-admin d-flex flex-column justify-content-center align-items-center" data-role="admin">
                  <img src="images/admin.png" alt="Admin" class="img-fluid mb-2" style="max-height:60px; max-width:60px">
                  <h6 class="fw-bold">Admin</h6>
                </div>
              </div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Prove you're human</label>
            <div class="d-flex gap-2 align-items-center">
              <div id="forgotCaptchaQuestion" class="captcha-question"><?= htmlspecialchars($forgot_captcha['question']) ?></div>
              <button type="button" id="forgotCaptchaRefresh" class="btn btn-sm btn-outline-secondary captcha-refresh" aria-label="Refresh captcha">↻</button>
            </div>
            <input type="hidden" name="captcha_id" id="forgotCaptchaId" value="<?= htmlspecialchars($forgot_captcha['id']) ?>">
            <input type="text" name="captcha_answer" id="forgotCaptchaAnswer" class="form-control mt-2" placeholder="Answer" required autocomplete="off">
            <div id="forgotCaptchaError" class="form-text text-danger" style="display:none;"></div>
          </div>

          <div id="forgotStatus" class="mb-3" style="display:none;"></div>
          <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
/* Improved verifyCaptcha + Forgot form handler (drop-in replacement) */

async function verifyCaptcha(id, answer) {
  // Use an explicit path for the verify endpoint — adjust if index.php lives in a subfolder.
  // This will hit the same directory as the current page
  const url = (window.location.pathname.endsWith('index.php') ? window.location.pathname : '/index.php') + '?action=verify';

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captcha_id: id, captcha_answer: answer }),
      credentials: 'same-origin'
    });

    // If server returned a non-JSON page (404/500/HTML), surface that
    const text = await res.text();
    try {
      const json = JSON.parse(text);
      return json;
    } catch (e) {
      console.warn('verifyCaptcha: unexpected server response:', res.status, text);
      return { success: false, message: (res.status >= 500 ? 'Server error while verifying captcha.' : 'Unexpected response from server.') };
    }
  } catch (err) {
    console.error('verifyCaptcha fetch error:', err);
    return { success: false, message: 'Network error while verifying captcha. Is the PHP server running and reachable at this origin?' };
  }
}

document.addEventListener('DOMContentLoaded', function () {
  const forgotForm = document.getElementById('forgotPasswordForm');
  const forgotStatus = document.getElementById('forgotStatus');
  const forgotRoleField = document.getElementById('forgotRoleField');
  const forgotCaptchaId = document.getElementById('forgotCaptchaId');
  const forgotCaptchaAnswer = document.getElementById('forgotCaptchaAnswer');
  const forgotCaptchaError = document.getElementById('forgotCaptchaError');
  const forgotEmailEl = document.getElementById('forgotEmail');
  let submitBtn = forgotForm && forgotForm.querySelector('button[type="submit"]');

  if (!forgotForm) return;

  // Ensure submit button is a button (not form-native submit)
  if (submitBtn && submitBtn.getAttribute('type') === 'submit') submitBtn.type = 'button';
  if (!submitBtn) {
    submitBtn = document.createElement('button');
    submitBtn.type = 'button';
    submitBtn.className = 'btn btn-primary w-100';
    submitBtn.textContent = 'Send Reset Link';
    forgotForm.appendChild(submitBtn);
  }

  function showForgotMessage(type, msg) {
    if (!forgotStatus) return;
    forgotStatus.style.display = 'block';
    forgotStatus.innerHTML = `<div class="alert alert-${type} mb-0">${msg}</div>`;
  }
  function clearForgotMessage() {
    if (!forgotStatus) return;
    forgotStatus.style.display = 'none';
    forgotStatus.innerHTML = '';
  }

  // Simple email regex (good enough for UI check; server must still validate)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Wire role selection inside modal so selection toggles hidden field
  document.querySelectorAll('#forgotPasswordModal .role-card').forEach(card => {
    card.addEventListener('click', () => {
      const row = card.closest('.row');
      if (row) row.querySelectorAll('.role-card').forEach(x => x.classList.remove('selected-role'));
      card.classList.add('selected-role');
      const role = card.getAttribute('data-role') || '';
      if (forgotRoleField) forgotRoleField.value = role;
    });
  });

  // Prevent native form submit on Enter
  forgotForm.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && e.target && e.target.tagName === 'INPUT') {
      e.preventDefault();
    }
  });

  // Main flow
  submitBtn.addEventListener('click', async function () {
    clearForgotMessage();
    if (forgotCaptchaError) { forgotCaptchaError.style.display = 'none'; forgotCaptchaError.textContent = ''; }

    const role = (forgotRoleField && forgotRoleField.value) ? forgotRoleField.value.trim() : '';
    if (!role) {
      showForgotMessage('warning', 'Please select a role (Student / Teacher / Admin).');
      return;
    }

    const email = forgotEmailEl ? forgotEmailEl.value.trim() : '';
    if (!email) {
      showForgotMessage('warning', 'Please enter your email.');
      return;
    }
    if (!emailRegex.test(email)) {
      showForgotMessage('warning', 'Please enter a valid email address (example@example.com).');
      return;
    }

    const captchaId = forgotCaptchaId ? forgotCaptchaId.value : '';
    const captchaAns = forgotCaptchaAnswer ? (forgotCaptchaAnswer.value || '').trim() : '';
    if (!captchaId || captchaAns === '') {
      if (forgotCaptchaError) {
        forgotCaptchaError.textContent = 'Please answer the captcha.';
        forgotCaptchaError.style.display = 'block';
      } else {
        showForgotMessage('warning', 'Please answer the captcha.');
      }
      return;
    }

    // UI feedback
    submitBtn.disabled = true;
    const origText = submitBtn.textContent || 'Send Reset Link';
    submitBtn.textContent = 'Verifying...';

    // Pre-verify captcha
    const verifyResp = await verifyCaptcha(captchaId, captchaAns);
    if (!verifyResp || !verifyResp.success) {
      const message = verifyResp?.message || 'Captcha verification failed.';
      if (forgotCaptchaError) {
        forgotCaptchaError.textContent = message;
        forgotCaptchaError.style.display = 'block';
      } else showForgotMessage('danger', message);

      // refresh captcha UI after a short pause
      setTimeout(() => { if (typeof refreshCaptchaUI === 'function') refreshCaptchaUI('forgot'); }, 700);
      submitBtn.disabled = false;
      submitBtn.textContent = origText;
      return;
    }

    // Build form data and POST to your backend (x-www-form-urlencoded)
    const payload = new URLSearchParams();
    payload.append('email', email);
    payload.append('role', role);
    payload.append('captcha_id', captchaId);
    payload.append('captcha_answer', captchaAns);

    submitBtn.textContent = 'Sending...';
    try {
      const resp = await fetch(forgotForm.getAttribute('action') || 'ForgotPass_BE.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: payload.toString(),
        credentials: 'same-origin'
      });

      const txt = await resp.text();
      let json = null;
      try { json = JSON.parse(txt); } catch (e) { json = null; }

      if (!json) {
        console.warn('ForgotPass_BE returned non-JSON:', resp.status, txt);
        showForgotMessage('danger', 'Unexpected server response. Check server console or network tab.');
      } else {
        const status = (json.status || '').toLowerCase();
        const message = json.message || json.email || 'Done';
        if (status === 'success' || status === 'update_success') {
          showForgotMessage('success', message || 'If the email exists, you will receive instructions.');
        } else {
          showForgotMessage('danger', message || 'Error: unable to process request.');
        }
      }
    } catch (err) {
      console.error('Forgot form fetch error:', err);
      showForgotMessage('danger', 'Network or server error while sending request. Is your PHP server running on http://localhost and reachable?');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = origText;
    }
  });
});
</script>

<!-- overlay for lockout -->
<div id="lockoutOverlay" style="display:none; position:fixed; inset:0; z-index:2000; background:rgba(0,0,0,0.6); color:#fff; align-items:center; justify-content:center; text-align:center; padding:2rem;">
  <div style="max-width:480px; width:100%; background:rgba(0,0,0,0.35); padding:2rem; border-radius:12px;">
    <h3 id="lockoutTitle">Too many failed attempts</h3>
    <p id="lockoutMessage">Please wait <span id="lockoutCountdown">0</span>s before trying again.</p>
    <button id="lockoutGotIt" class="btn btn-light" style="display:none;">OK</button>
  </div>
</div>

<style>

/* Student vivid hover */
.role-card.role-student:hover {
  background: linear-gradient(180deg,#06b6a4 0%, #059687 100%);
  color: #ffffff;
  border-color: #049b89;
}

/* Teacher vivid hover */
.role-card.role-teacher:hover {
  background: linear-gradient(180deg,#f59e0b 0%, #d97706 100%);
  color: #ffffff;
  border-color: #f59e0b;
}

/* Admin vivid hover */
.role-card.role-admin:hover {
  background: linear-gradient(180deg,#ef4444 0%, #dc2626 100%);
  color: #ffffff;
  border-color: #ef4444;
}

/* role-card hover vividness */
.role-card:hover img {
  filter: none;
  transform: scale(1.05);
  opacity: 1;
}

.role-card:hover h6 {
  color: #111; /* darker for light mode */
  font-weight: 800; /* stronger weight */
}

/* Dark mode hover vividness */
.modal-theme.dark .role-card:hover img {
  filter: none;
  transform: scale(1.05);
  opacity: 1;
}

.modal-theme.dark .role-card:hover h6 {
  color: #fff; /* bright white for dark mode */
  font-weight: 800;
}


.big-wrapper {
  transition: background-color 0.3s ease, color 0.3s ease;
}

.big-wrapper.light {
  background-color: #f1f8fc;
  color: #111111;
}

.big-wrapper.dark {
  background-color: #192e3a;
  color: #f5f5f5;
}


.role-card {
  cursor: pointer;
  padding: 0.9rem;
  border-radius: 12px;
  transition: transform .12s, box-shadow .12s, border-color .12s, background .12s;
  border: 2px solid transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: .25rem;
  user-select: none;
  background: transparent; /* neutral by default */
  color: #111827;
}

/* small hover lift for all */
.role-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 24px rgba(16,24,40,0.06);
}

/* icon / image treatment */
.role-card img {
  width: 60px;
  height: 60px;
  object-fit: contain;
  transition: filter .12s, transform .12s, opacity .12s;
  filter: grayscale(80%) contrast(.9);
  opacity: .92;
}

/* label */
.role-card h6 {
  margin: 0;
  font-size: 0.95rem;
  font-weight: 700;
  transition: color .12s;
  color: inherit;
}

/* subtle base tints (unselected but readable) */
.role-card.role-student {
  background: linear-gradient(180deg,#f2fffb 0%, #ecfdf7 100%);
  border-color: rgba(14,165,164,0.08);
  color: #074b47;
}
.role-card.role-teacher {
  background: linear-gradient(180deg,#fffdf6 0%, #fffbeb 100%);
  border-color: rgba(245,158,11,0.08);
  color: #6a4a09;
}
.role-card.role-admin {
  background: linear-gradient(180deg,#fff6f7 0%, #fff1f2 100%);
  border-color: rgba(239,68,68,0.08);
  color: #60151a;
}

/* selected state — vivid and unmistakable */
.role-card.selected-role {
  transform: translateY(-6px);
  box-shadow: 0 18px 40px rgba(2,6,23,0.16);
  border-width: 2px;
}

/* student selected */
.role-card.role-student.selected-role {
  background: linear-gradient(180deg,#06b6a4 0%, #059687 100%);
  color: #ffffff;
  border-color: #049b89;
}
.role-card.role-student.selected-role img {
  filter: none;
  transform: scale(1.06);
  opacity: 1;
}

/* teacher selected */
.role-card.role-teacher.selected-role {
  background: linear-gradient(180deg,#f59e0b 0%, #d97706 100%);
  color: #ffffff;
  border-color: #f59e0b;
}
.role-card.role-teacher.selected-role img {
  filter: none;
  transform: scale(1.06);
  opacity: 1;
}

/* admin selected */
.role-card.role-admin.selected-role {
  background: linear-gradient(180deg,#ef4444 0%, #dc2626 100%);
  color: #ffffff;
  border-color: #ef4444;
}
.role-card.role-admin.selected-role img {
  filter: none;
  transform: scale(1.06);
  opacity: 1;
}

/* focus-visible for keyboard users */
.role-card:focus-visible {
  outline: 3px solid rgba(59,130,246,0.18);
  outline-offset: 2px;
}

/* ensure small screens remain tidy */
@media (max-width:480px) {
  .role-card img { width:52px; height:52px; }
  .role-card { padding: .65rem; border-radius:10px; }
}



/* Dark mode styles for the modal */
.modal-theme.dark .modal-content {
    background-color: #192e3a;  /* Dark background for the modal */
    color: #fff;  /* Light text */
}

.modal-theme.dark .modal-header {
    background-color: #192e3a;  /* Darker header */
}

.modal-theme.dark .form-control {
    background-color: #333;  /* Dark input fields */
    color: #fff;  /* Light text */
    border-color: #444;  /* Dark border color */
}

.modal-theme.dark .btn {
    background-color: #444;  /* Dark button background */
    color: #fff;  /* Light button text */
}

.modal-theme.dark .role-card {
    background-color: #333;  /* Dark background for role cards */
    color: #fff;  /* Light text color */
    border: 2px solid transparent;  /* Transparent border */
    transition: background-color 0.2s, border-color 0.2s;  /* Smooth transition for hover */
}

.modal-theme.dark .role-card:hover {
    background-color: #555;  /* Slightly lighter on hover */
    border-color: #666;  /* Slight border color */
}

.modal-theme.dark .btn-eye {
    background-color: #555;  /* Eye button background */
    color: #fff;  /* Icon color */
}

/* Ensure proper hover effects on buttons in dark mode */
.modal-theme.dark .btn:hover {
    background-color: #666;  /* Darker hover for buttons */
}

.modal-theme.dark .role-card:hover {
    background-color: #444;  /* Darker background on hover */
}

/* Ensure proper hover effects on role cards */
.modal-theme.dark .role-card.selected-role {
    background-color: #555;  /* Selected role background */
    border-color: #666;
}

.modal-theme.dark .role-card.selected-role:hover {
    background-color: #666;  /* Slightly lighter selected role hover */
}

/* Ensure smooth transitions for dark mode and hover states */
.modal-theme.dark .modal-header, .modal-theme.dark .modal-footer {
    transition: background-color 0.3s ease;
}

</style>

<script>



// expose server lock info from PHP (session-driven)
const SERVER_LOCK_INFO = <?php echo json_encode($server_lock_info, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

/* client JS: fetch/verify captchas, defensive wiring, and progressive lockout overlay.
   progressive thresholds: 3 -> 5s, 6 -> 60s, 9 -> 300s, 12 -> 600s (capped)
*/

(function () {
    // ---------- helpers ----------
    function qs(name) {
        const u = new URL(location.href);
        const v = u.searchParams.get(name);
        return v;
    }

    function parseIntSafe(v, fallback=0) {
        const n = parseInt(v);
        return Number.isFinite(n) ? n : fallback;
    }

    // post JSON helper
    async function postJson(url, data) {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
            credentials: 'same-origin'
        });
        return res.json();
    }

    // fetch captcha
    async function fetchCaptcha(target) {
        try {
            const resp = await fetch('index.php?action=captcha&target=' + encodeURIComponent(target), { credentials: 'same-origin' });
            if (!resp.ok) throw new Error('Network error');
            return resp.json();
        } catch (err) {
            console.error('fetchCaptcha error', err);
            return null;
        }
    }

    // refresh captcha UI
    async function refreshCaptchaUI(target) {
        const j = await fetchCaptcha(target);
        if (!j) return;
        if (target === 'login') {
            const q = document.getElementById('loginCaptchaQuestion');
            const id = document.getElementById('loginCaptchaId');
            const ans = document.getElementById('loginCaptchaAnswer');
            const err = document.getElementById('loginCaptchaError');
            if (q) q.textContent = j.question;
            if (id) {
                id.value = j.id;
                id.setAttribute('name', 'captcha_id');
            }
            if (ans) {
                ans.value = '';
                ans.setAttribute('name', 'captcha_answer');
            }
            if (err) err.style.display = 'none';
        } else {
            const q = document.getElementById('forgotCaptchaQuestion');
            const id = document.getElementById('forgotCaptchaId');
            const ans = document.getElementById('forgotCaptchaAnswer');
            const err = document.getElementById('forgotCaptchaError');
            if (q) q.textContent = j.question;
            if (id) {
                id.value = j.id;
                id.setAttribute('name', 'captcha_id');
            }
            if (ans) {
                ans.value = '';
                ans.setAttribute('name', 'captcha_answer');
            }
            if (err) err.style.display = 'none';
        }
    }

    // verify captcha
    async function verifyCaptcha(id, answer) {
        try {
            const j = await postJson('index.php?action=verify', { captcha_id: id, captcha_answer: answer });
            return j;
        } catch (err) {
            console.error('verifyCaptcha error', err);
            return { success: false, message: 'Network error' };
        }
    }

    // ---------- progressive lockout logic (client-side) ----------
    // mapping escalation level -> seconds
    const ESCALATION_SECONDS = [0, 5, 60, 300, 600]; // index 1..4 used
    const MAX_ESCALATION_LEVEL = 4;

    function getEscalationLevel() {
        return parseIntSafe(localStorage.getItem('esc_level') || '0', 0);
    }
    function setEscalationLevel(v) {
        localStorage.setItem('esc_level', String(Math.min(MAX_ESCALATION_LEVEL, Math.max(0, v))));
    }

    function getOverlayUntil() {
        return parseIntSafe(localStorage.getItem('lockout_until') || '0', 0);
    }
    function setOverlayUntil(ts) {
        if (ts <= 0) localStorage.removeItem('lockout_until');
        else localStorage.setItem('lockout_until', String(ts));
    }

    function getLastServerLockProcessed() {
        return parseIntSafe(localStorage.getItem('last_server_lock'), 0);
    }
    function setLastServerLockProcessed(ts) {
        localStorage.setItem('last_server_lock', String(ts));
    }

    function showLockoutOverlay(untilTs, messageOverride) {
        const overlay = document.getElementById('lockoutOverlay');
        const countdownEl = document.getElementById('lockoutCountdown');
        const title = document.getElementById('lockoutTitle');
        const message = document.getElementById('lockoutMessage');
        if (!overlay || !countdownEl) return;

        function disableAllInputs(disabled) {
            document.querySelectorAll('input, button, select, textarea').forEach(el => {
                // keep overlay button enabled
                if (overlay.contains(el)) return;
                if (disabled) {
                    el.setAttribute('data-prev-tabindex', el.tabIndex);
                    el.setAttribute('disabled', 'disabled');
                } else {
                    el.removeAttribute('disabled');
                }
            });
        }

        overlay.style.display = 'flex';
        if (messageOverride) message.textContent = messageOverride;

        disableAllInputs(true);

        function tick() {
            const now = Math.floor(Date.now() / 1000);
            let remaining = Math.max(0, untilTs - now);
            countdownEl.textContent = remaining;
            if (remaining <= 0) {
                overlay.style.display = 'none';
                disableAllInputs(false);
                setOverlayUntil(0);
                clearInterval(iv);
            }
        }
        tick();
        const iv = setInterval(tick, 500);
    }

    // process server-provided attempts/locked_until either from SERVER_LOCK_INFO (session) or URL params
    function processServerLockParams() {
        let attempts = 0;
        let server_locked_until = 0;
        let login_error = '';
        let role = '';

        if (typeof SERVER_LOCK_INFO !== 'undefined' && SERVER_LOCK_INFO) {
            attempts = parseIntSafe(SERVER_LOCK_INFO.attempts, 0);
            server_locked_until = parseIntSafe(SERVER_LOCK_INFO.locked_until, 0);
            login_error = SERVER_LOCK_INFO.login_error || '';
            role = SERVER_LOCK_INFO.role || '';
        } else {
            login_error = qs('login_error');
            attempts = parseIntSafe(qs('attempts'), 0);
            server_locked_until = parseIntSafe(qs('locked_until'), 0);
            role = qs('role') || '';
        }

        // show server message inside login modal (helps avoid link-based errors)
        if (login_error) {
            const serverStatus = document.getElementById('serverStatus');
            if (serverStatus) {
                serverStatus.style.display = 'block';
                serverStatus.innerHTML = `<div class="alert alert-danger mb-0">${login_error}</div>`;
            }
            // if role present, preselect and open login modal
            if (role) {
                const rf = document.getElementById('roleField');
                const s = document.getElementById('selectedRoleLabel');
                if (rf) rf.value = role;
                if (s) s.textContent = role.charAt(0).toUpperCase() + role.slice(1);
            }
            // open modal so user sees message
            try {
                const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
                loginModal.show();
            } catch (e) { /* ignore */ }
        }

        // If server reports locked_until and it's a new lock, bump escalation.
        if (server_locked_until > 0) {
            const lastProcessed = getLastServerLockProcessed();
            if (server_locked_until !== lastProcessed) {
                let level = getEscalationLevel();
                level = Math.min(MAX_ESCALATION_LEVEL, level + 1);
                setEscalationLevel(level);
                setLastServerLockProcessed(server_locked_until);
            }
            const now = Math.floor(Date.now() / 1000);
            let clientDur = ESCALATION_SECONDS[getEscalationLevel()] || 0;
            let clientUntil = now + clientDur;
            const overlayUntil = Math.max(server_locked_until, clientUntil);
            setOverlayUntil(overlayUntil);
        } else if (login_error) {
            // No server locked_until but login_error present (a failed attempt). If attempts hits thresholds, increase escalation.
            if (attempts > 0 && attempts % 3 === 0) {
                const marker = parseIntSafe(localStorage.getItem('last_attempts_marker') || '0', 0);
                if (attempts !== marker) {
                    let level = getEscalationLevel();
                    level = Math.min(MAX_ESCALATION_LEVEL, level + 1);
                    setEscalationLevel(level);
                    localStorage.setItem('last_attempts_marker', String(attempts));
                    const now = Math.floor(Date.now() / 1000);
                    const until = now + (ESCALATION_SECONDS[level] || 0);
                    setOverlayUntil(until);
                }
            }
        }
    }

    function checkAndShowOverlayOnLoad() {
        const until = getOverlayUntil();
        const now = Math.floor(Date.now() / 1000);
        if (until > now) {
            showLockoutOverlay(until, 'Too many failed attempts. Please wait:');
        } else {
            setOverlayUntil(0);
        }
    }

    // ---------- DOM wiring ----------
    document.addEventListener('DOMContentLoaded', function () {

        // toggle password visibility
        try {
            const passwordInput = document.getElementById('loginPassword');
            const toggleIcon = document.getElementById('togglePasswordIcon');
            if (passwordInput && toggleIcon) {
                toggleIcon.addEventListener('click', function () {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    toggleIcon.classList.toggle('bi-eye');
                    toggleIcon.classList.toggle('bi-eye-slash');
                });
            }
        } catch (e) { console.warn(e); }

        // Defensive refresh wiring (prevent accidental submit)
        const loginRefresh = document.getElementById('loginCaptchaRefresh');
        const forgotRefresh = document.getElementById('forgotCaptchaRefresh');
        if (loginRefresh) {
            loginRefresh.addEventListener('click', function (e) {
                e.preventDefault(); e.stopPropagation();
                refreshCaptchaUI('login');
            });
        }
        if (forgotRefresh) {
            forgotRefresh.addEventListener('click', function (e) {
                e.preventDefault(); e.stopPropagation();
                refreshCaptchaUI('forgot');
            });
        }

        // role-card clicks
        document.querySelectorAll('.role-card').forEach(card => {
            card.addEventListener('click', function () {
                const role = card.getAttribute('data-role');
                if (!role) return;

                // mark selection visual
                const parentRow = card.closest('.row');
                if (parentRow) parentRow.querySelectorAll('.role-card').forEach(x => x.classList.remove('selected-role'));
                card.classList.add('selected-role');

                const loginRoleModal = document.getElementById('loginRoleModal');
                if (loginRoleModal && loginRoleModal.contains(card)) {
                    const s = document.getElementById('selectedRoleLabel');
                    if (s) s.textContent = role.charAt(0).toUpperCase() + role.slice(1);
                    const rf = document.getElementById('roleField');
                    if (rf) rf.value = role;
                    const roleModalEl = document.getElementById('loginRoleModal');
                    const roleModal = bootstrap.Modal.getInstance(roleModalEl) || new bootstrap.Modal(roleModalEl);
                    try { roleModal.hide(); } catch (e) { /* ignore */ }
                    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
                    try { loginModal.show(); } catch (e) { /* ignore */ }
                }

                const forgotModal = document.getElementById('forgotPasswordModal');
                if (forgotModal && forgotModal.contains(card)) {
                    const forgotRF = document.getElementById('forgotRoleField');
                    if (forgotRF) forgotRF.value = role;
                }
            });
        });

        // Prevent Enter from submitting the captcha input
        const loginAns = document.getElementById('loginCaptchaAnswer');
        if (loginAns) loginAns.addEventListener('keydown', e => { if (e.key === 'Enter') e.preventDefault(); });
        const forgotAns = document.getElementById('forgotCaptchaAnswer');
        if (forgotAns) forgotAns.addEventListener('keydown', e => { if (e.key === 'Enter') e.preventDefault(); });

        // LOGIN handler (AJAX preverify then submit)
        const loginForm = document.getElementById('roleLoginForm');
        if (loginForm) {
            let isSubmitting = false;
            const onLoginSubmit = async function (e) {
                e.preventDefault();
                if (isSubmitting) return;

                const hp = document.getElementById('hp_name');
                if (hp && hp.value.trim() !== '') {
                    const err = document.getElementById('loginCaptchaError');
                    if (err) { err.textContent = 'Invalid submission.'; err.style.display = 'block'; }
                    return;
                }

                const idEl = document.getElementById('loginCaptchaId');
                const ansEl = document.getElementById('loginCaptchaAnswer');
                const errEl = document.getElementById('loginCaptchaError');
                const submitBtn = document.getElementById('loginSubmitBtn');

                if (!idEl || !ansEl || !errEl || !submitBtn) {
                    loginForm.submit();
                    return;
                }

                isSubmitting = true;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Verifying...';

                const resp = await verifyCaptcha(idEl.value, ansEl.value);

                if (resp && resp.success) {
                    isSubmitting = false;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Login';
                    loginForm.submit();
                } else {
                    if (errEl) {
                        errEl.textContent = resp?.message || 'Captcha failed. Please try again.';
                        errEl.style.display = 'block';
                    }
                    isSubmitting = false;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Login';
                    setTimeout(() => refreshCaptchaUI('login'), 700);
                }
            };
            loginForm.addEventListener('submit', onLoginSubmit);
        }

        // FORGOT handler (AJAX preverify then submit)
        const forgotForm = document.getElementById('forgotPasswordForm');
        if (forgotForm) {
            let isSubmitting = false;
            const onForgotSubmit = async function (e) {
                e.preventDefault();
                if (isSubmitting) return;

                const idEl = document.getElementById('forgotCaptchaId');
                const ansEl = document.getElementById('forgotCaptchaAnswer');
                const errEl = document.getElementById('forgotCaptchaError');
                const submitBtn = forgotForm.querySelector('button[type="submit"]');

                if (!idEl || !ansEl || !errEl || !submitBtn) {
                    forgotForm.submit();
                    return;
                }

                isSubmitting = true;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Verifying...';

                const resp = await verifyCaptcha(idEl.value, ansEl.value);

                if (resp && resp.success) {
                    isSubmitting = false;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Send Reset Link';
                    forgotForm.submit();
                } else {
                    if (errEl) {
                        errEl.textContent = resp?.message || 'Captcha failed. Please try again.';
                        errEl.style.display = 'block';
                    }
                    isSubmitting = false;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Send Reset Link';
                    setTimeout(() => refreshCaptchaUI('forgot'), 700);
                }
            };
            forgotForm.addEventListener('submit', onForgotSubmit);
        }

        // Final: refresh captchas once DOM is ready so session-state is fresh
        refreshCaptchaUI('login');
        refreshCaptchaUI('forgot');

        // Process server-sent attempt/lock info (via SESSION-exposed SERVER_LOCK_INFO) or URL params
        processServerLockParams();
        // If a lock is active in localStorage, show overlay
        checkAndShowOverlayOnLoad();
    });

})();
</script>

<?php include('shared/_footer.php'); ?>
